from convolution_model_tools.convolution_2D_tools import model_2D_tool
from dense_model_tools.dense_tools import model_Dense_Layer
from all_models_tools.all_model_tools import add_Activative, add_dropout
from keras.layers import Flatten, GlobalAveragePooling2D, MaxPooling2D, Dense, Conv2D, Dropout, TimeDistributed, LSTM, Input
from keras.activations import softmax, sigmoid

def one_layer_cnn_model():
    tools = model_2D_tool()
    dense_tool = model_Dense_Layer()

    img_Input = tools.add_2D_input()
    x = tools.add_Convolution2D(img_Input, 32)
    x = add_Activative(x)
    x = tools.add_MaxPooling(x)

    x = tools.add_Convolution2D(x, 64)
    x = add_Activative(x)
    x = tools.add_MaxPooling(x)

    flatter = tools.add_flatten(x)

    dense = dense_tool.add_dense(64, flatter)
    dense = add_Activative(dense)
    dense = dense_tool.add_dense(32, dense)
    dense = add_Activative(dense)
    dense = dense_tool.add_dense(7, dense)
    dense = add_Activative(dense, softmax)
    return img_Input, dense

def find_example_cnn_model():
    tools = model_2D_tool()
    dense_tool = model_Dense_Layer()

    img_Input = tools.add_2D_input()

    x = tools.add_Convolution2D(img_Input, 16)
    x = add_Activative(x)
    x = add_dropout(x, 0.25)

    x = tools.add_Convolution2D(x, 32)
    x = add_Activative(x)
    x = add_dropout(x, 0.25)

    x = tools.add_MaxPooling(x)

    x = tools.add_Convolution2D(x, 64)
    x = add_Activative(x)
    x = add_dropout(x, 0.25)

    x = tools.add_MaxPooling(x)

    x = tools.add_Convolution2D(x, 128)
    x = add_Activative(x)
    x = add_dropout(x, 0.25)

    x = tools.add_MaxPooling(x)

    flatter = tools.add_flatten(x)

    dense = dense_tool.add_dense(64, flatter)
    dense = add_Activative(dense)
    dense = add_dropout(dense, 0.25)
    dense = dense_tool.add_dense(7, dense)
    dense = add_Activative(dense, sigmoid)

    return img_Input, dense

def change_example_cnn_model():
    tools = model_2D_tool()
    dense_tool = model_Dense_Layer()

    img_Input = tools.add_2D_input()

    x = tools.add_Convolution2D(img_Input, 16)
    x = add_Activative(x)
    x = tools.add_batchnomlization(x)

    x = tools.add_Convolution2D(x, 32)
    x = add_Activative(x)
    x = tools.add_batchnomlization(x)

    x = tools.add_MaxPooling(x)

    x = tools.add_Convolution2D(x, 64)
    x = add_Activative(x)
    x = tools.add_batchnomlization(x)

    x = tools.add_MaxPooling(x)

    x = tools.add_Convolution2D(x, 128)
    x = add_Activative(x)
    x = tools.add_batchnomlization(x)

    x = tools.add_MaxPooling(x)

    flatter = tools.add_flatten(x)

    dense = dense_tool.add_dense(64, flatter)
    dense = add_Activative(dense)
    dense = add_dropout(dense, 0.3)
    dense = dense_tool.add_dense(7, dense)
    dense = add_Activative(dense, softmax)

    return img_Input, dense

def two_convolution_cnn_model():
    tools = model_2D_tool()
    dense_tool = model_Dense_Layer()

    img_Input = tools.add_2D_input()
    x = tools.add_two_floors_convolution2D(img_Input, 32)
    x = tools.add_MaxPooling(x)

    x = tools.add_two_floors_convolution2D(x, 64)
    x = tools.add_MaxPooling(x)

    flatter = tools.add_flatten(x)

    dense = dense_tool.add_dense(64, flatter)
    dense = add_Activative(dense)
    dense = dense_tool.add_dense(32, dense)
    dense = add_Activative(dense)
    dense = dense_tool.add_dense(7, dense)
    dense = add_Activative(dense, softmax)
    return img_Input, dense

def cnn_LSTM():
    head = Input(shape = (150, 150, 3))
    inputs = Conv2D(filters = 64, strides = 1, kernel_size = (3, 3), padding = "same", activation = "relu")(head)
    inputs = Conv2D(filters = 64, strides = 1, kernel_size = (3, 3), padding = "same", activation = "relu")(inputs)
    inputs = MaxPooling2D(strides = 2, pool_size = (2, 2))(inputs)
    inputs = Dropout(0.25)(inputs)

    inputs = Conv2D(filters = 128, strides = 1, kernel_size = (3, 3), padding = "same", activation = "relu")(inputs)
    inputs = Conv2D(filters = 128, strides = 1, kernel_size = (3, 3), padding = "same", activation = "relu")(inputs)
    inputs = MaxPooling2D(strides = 2, pool_size = (2, 2))(inputs)
    inputs = Dropout(0.25)(inputs)

    inputs = Conv2D(filters = 256, strides = 1, kernel_size = (3, 3), padding = "same", activation = "relu")(inputs)
    inputs = Conv2D(filters = 256, strides = 1, kernel_size = (3, 3), padding = "same", activation = "relu")(inputs)
    inputs = MaxPooling2D(strides = 2, pool_size = (2, 2))(inputs)
    inputs = Dropout(0.25)(inputs)

    inputs = Conv2D(filters = 512, strides = 1, kernel_size = (3, 3), padding = "same", activation = "relu")(inputs)
    inputs = Conv2D(filters = 512, strides = 1, kernel_size = (3, 3), padding = "same", activation = "relu")(inputs)
    inputs = Conv2D(filters = 512, strides = 1, kernel_size = (3, 3), padding = "same", activation = "relu")(inputs)
    inputs = MaxPooling2D(strides = 2, pool_size = (2, 2))(inputs)
    inputs = Dropout(0.25)(inputs)

    inputs = Conv2D(filters = 512, strides = 1, kernel_size = (3, 3), padding = "same", activation = "relu")(inputs)
    inputs = Conv2D(filters = 512, strides = 1, kernel_size = (3, 3), padding = "same", activation = "relu")(inputs)
    inputs = Conv2D(filters = 512, strides = 1, kernel_size = (3, 3), padding = "same", activation = "relu")(inputs)
    inputs = MaxPooling2D(strides = 2, pool_size = (2, 2))(inputs)
    inputs = Dropout(0.25)(inputs)
    inputs = TimeDistributed(Flatten())(inputs)

    inputs = LSTM(units = 49)(inputs)
    inputs = Dense(units = 64)(inputs)
    output = Dense(units = 7, activation = "softmax")(inputs)

    return head, output