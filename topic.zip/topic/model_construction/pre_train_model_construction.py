from convolution_model_tools.convolution_2D_tools import model_2D_tool
from dense_model_tools.dense_tools import model_Dense_Layer
from all_models_tools.all_model_tools import add_Activative, add_dropout, attention_block, Change_Status
from keras.activations import softmax, sigmoid
from keras.applications import VGG19, ResNet50, NASNetLarge, DenseNet201, Xception
from keras import regularizers
from keras.layers import Add
from application.Xception_indepentment import Xception_indepentment   

def VGG19_model():
    tools = model_2D_tool()
    dense_tool = model_Dense_Layer()

    vgg19 = VGG19(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    flatten = tools.add_flatten(vgg19.output)
    dense = dense_tool.add_dense(64, flatten)
    dense = add_Activative(dense)
    dense = dense_tool.add_dense(7, dense)
    dense = add_Activative(dense, softmax)

    return vgg19, dense  

def Resnet50_model():
    tools = model_2D_tool()
    dense_tool = model_Dense_Layer()

    vgg19 = ResNet50(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    flatten = tools.add_flatten(vgg19.output)
    dense = dense_tool.add_dense(64, flatten)
    dense = add_Activative(dense)
    dense = dense_tool.add_dense(7, dense)
    dense = add_Activative(dense, softmax)

    return vgg19, dense  

def DenseNet201_model():
    tools = model_2D_tool()
    dense_tool = model_Dense_Layer()

    Densenet201 = DenseNet201(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    flatten = tools.add_flatten(Densenet201.output)
    dense = dense_tool.add_dense(64, flatten)
    dense = add_Activative(dense)
    dense = dense_tool.add_dense(7, dense)
    dense = add_Activative(dense, softmax)

    return Densenet201, dense

def Original_DenseNet201_model():
    tools = model_2D_tool()
    dense_tool = model_Dense_Layer()

    Densenet201 = DenseNet201(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    GAP = tools.add_globalAveragePooling(Densenet201.output)
    dense = dense_tool.add_dense(7, GAP)
    dense = add_Activative(dense, softmax)

    return Densenet201, dense

def Original_Xception_model():
    tools = model_2D_tool()
    dense_tool = model_Dense_Layer()

    xception = Xception(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    GAP = tools.add_globalAveragePooling(xception.output)
    dense = dense_tool.add_dense(7, GAP)
    output = add_Activative(dense, softmax)

    return xception, output

def Add_residual_block_and_two_layers_in_Xception_model():
    tools = model_2D_tool()
    dense_tool = model_Dense_Layer()

    xception = Xception(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    GAP = tools.add_globalAveragePooling(xception.output)

    dense = tools.residual_block(GAP, 1370, 913)

    dense = dense_tool.add_dense(7, dense)
    output = add_Activative(dense, softmax)

    return xception, output

def Add_residual_block_and_three_layers_in_Xception_model():
    tools = model_2D_tool()
    dense_tool = model_Dense_Layer()

    xception = Xception(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    GAP = tools.add_globalAveragePooling(xception.output)

    dense = tools.residual_block(GAP, 1370, 913)

    dense = dense_tool.add_dense(613, dense)
    dense = add_Activative(dense)

    dense = dense_tool.add_dense(7, dense)
    output = add_Activative(dense, softmax)

    return xception, output

def Add_residual_block_and_five_layers_in_Xception_model():
    tools = model_2D_tool()
    dense_tool = model_Dense_Layer()

    xception = Xception(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    GAP = tools.add_globalAveragePooling(xception.output)

    dense = tools.residual_block(GAP, 1370, 913)
    dense = tools.residual_block(dense, 913, 414)

    dense = dense_tool.add_dense(276, dense)
    dense = add_Activative(dense)

    dense = dense_tool.add_dense(7, dense)
    output = add_Activative(dense, softmax)

    return xception, output

def Add_attention_block_in_Xception_model():
    tools = model_2D_tool()
    dense_tool = model_Dense_Layer()

    # Xception部分重架
    xception = Xception(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    for layer in xception.layers:
        if "conv2d" in layer.name:
            x = attention_block(layer.output)
            Status = Change_Status(layer.output)
            Status.output = Add()([layer.output, x])

    GAP = tools.add_globalAveragePooling(x)

    dense = dense_tool.add_dense(1370, GAP)
    dense = add_Activative(dense)

    dense = dense_tool.add_dense(7, dense)
    output = add_Activative(dense, softmax)

    return xception, output

def VGG19_many_Dense_layer(start_unit, layers):
    # model = ResNet50
    conv_tools = model_2D_tool()
    dense_tools = model_Dense_Layer()

    vgg19 = VGG19(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    GAP = conv_tools.add_globalAveragePooling(vgg19.output)

    dense = dense_tools.add_regularizer_kernel_dense(unit = 4096, input_data = GAP, regularizer = regularizers.L2(0.0005))
    dense = add_Activative(input = dense)
    dense = add_dropout(input = dense, drop = 0.5)

    dense = dense_tools.add_regularizer_kernel_dense(unit = 4096, input_data = dense, regularizer = regularizers.L2(0.0005))
    dense = add_Activative(input = dense)
    dense = add_dropout(input = dense, drop = 0.5)

    dense = dense_tools.add_dense(unit = 2735, input_data = dense)
    dense = add_Activative(input = dense)
    dense = add_dropout(input = dense, drop = 0.5)

    # for i in range(layers):
    #     dense = dense_tools.add_dense(unit = start_unit, input_data = dense)
    #     dense = add_Activative(input = dense)
    #     start_unit /= 2

    output = dense_tools.add_dense(unit = 7, input_data = dense)
    output = add_Activative(output, softmax)
    return vgg19, output

def original_VGG19():
    # model = ResNet50
    conv_tools = model_2D_tool()
    dense_tools = model_Dense_Layer()

    vgg19 = VGG19(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    GAP = conv_tools.add_globalAveragePooling(vgg19.output)

    dense = dense_tools.add_regularizer_kernel_dense(unit = 4096, input_data = GAP, regularizer = regularizers.L2(0.0005))
    dense = add_Activative(input = dense)
    dense = add_dropout(input = dense, drop = 0.5)

    dense = dense_tools.add_regularizer_kernel_dense(unit = 4096, input_data = dense, regularizer = regularizers.L2(0.0005))
    dense = add_Activative(input = dense)
    dense = add_dropout(input = dense, drop = 0.5)

    output = dense_tools.add_dense(unit = 7, input_data = dense)
    output = add_Activative(output, softmax)
    return vgg19, output

def ResNet50_many_Dense_layer(start_unit, layers):
    # model = ResNet50
    conv_tools = model_2D_tool()
    dense_tools = model_Dense_Layer()

    resnet = ResNet50(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    GAP = conv_tools.add_globalAveragePooling(resnet.output)

    # for i in range(layers):
    #     dense = dense_tools.add_dense(unit = start_unit, input_data = dense)
    #     dense = add_Activative(input = dense)
    #     start_unit /= 2

    output = dense_tools.add_dense(unit = 7, input_data = GAP)
    return resnet, output

def Xception_many_Dense_layer(start_unit, layers):
    # model = ResNet50
    conv_tools = model_2D_tool()
    dense_tools = model_Dense_Layer()

    xception = Xception(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    dense = conv_tools.add_globalAveragePooling(xception.output)

    dense = dense_tools.add_dense(unit = 1370, input_data = dense)
    dense = add_Activative(input = dense)  

    # dense = dense_tools.add_dense(unit = 128, input_data = dense)
    # dense = add_Activative(input = dense) 

    # dense = dense_tools.add_dense(unit = 64, input_data = dense)
    # dense = add_Activative(input = dense)   

    # for i in range(layers):
    #     dense = dense_tools.add_dense(unit = start_unit, input_data = dense)
    #     dense = add_Activative(input = dense)
    #     start_unit /= 2

    dense = dense_tools.add_dense(unit = 7, input_data = dense)
    output = add_Activative(dense, softmax)
    return xception, output

def DenseNet201_many_Dense_layer(start_unit, layers):
    # model = ResNet50
    conv_tools = model_2D_tool()
    dense_tools = model_Dense_Layer()

    dnesenet201 = DenseNet201(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    dense = conv_tools.add_globalAveragePooling(dnesenet201.output)

    dense = dense_tools.add_dense(unit = 1285, input_data = dense)
    dense = add_Activative(input = dense)

    dense = dense_tools.add_dense(unit = 7, input_data = dense)
    output = add_Activative(dense, softmax)

    # for i in range(layers):
    #     dense = dense_tools.add_dense(unit = start_unit, input_data = dense)
    #     dense = add_Activative(input = dense)
    #     start_unit /= 2

    
    return dnesenet201, output

def add_regularizers_L1(): # 比較正規化
    tools = model_2D_tool()
    dense_tool = model_Dense_Layer()

    xception = Xception(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    GAP = tools.add_globalAveragePooling(xception.output)
    dense = dense_tool.add_regularizer_kernel_dense(1370, GAP, regularizers.L1())
    dense = add_Activative(dense)
    dense = dense_tool.add_dense(7, dense)
    dense = add_Activative(dense, softmax)

    return xception, dense

def add_regularizers_L2(): # 比較正規化
    tools = model_2D_tool()
    dense_tool = model_Dense_Layer()

    xception = Xception(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    GAP = tools.add_globalAveragePooling(xception.output)
    dense = dense_tool.add_regularizer_kernel_dense(1370, GAP, regularizers.L2())
    dense = add_Activative(dense)
    dense = dense_tool.add_dense(7, dense)
    dense = add_Activative(dense, softmax)

    return xception, dense

def add_regularizers_L1L2(): # 比較正規化
    tools = model_2D_tool()
    dense_tool = model_Dense_Layer()

    xception = Xception(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    GAP = tools.add_globalAveragePooling(xception.output)
    dense = dense_tool.add_regularizer_kernel_dense(64, GAP, regularizers.L1L2())
    dense = add_Activative(dense)
    dense = dense_tool.add_dense(7, dense)
    dense = add_Activative(dense, softmax)

    return xception, dense

def add_bias_regularizers(): # 比較正規化
    tools = model_2D_tool()
    dense_tool = model_Dense_Layer()

    xception = Xception(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    GAP = tools.add_globalAveragePooling(xception.output)
    dense = dense_tool.add_regularizer_bias_dense(1370, GAP, regularizers.L2())
    dense = add_Activative(dense)
    dense = dense_tool.add_dense(7, dense)
    dense = add_Activative(dense, softmax)

    return xception, dense

def Change_Regularization_Coefficient(Coefficient):
    tools = model_2D_tool()
    Dense_Tools = model_Dense_Layer()

    xception = Xception(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    GAP = tools.add_globalAveragePooling(xception.output)
    dense = Dense_Tools.add_regularizer_kernel_dense(1370, GAP, regularizers.L2(Coefficient))
    dense = add_Activative(dense)
    dense = Dense_Tools.add_dense(7, dense)
    output = add_Activative(dense, softmax)

    return xception, output

def Change_Dropout_Coefficient(Dropout_Coefficient):
    tools = model_2D_tool()
    Dense_Tools = model_Dense_Layer()

    xception = Xception(include_top = False, weights = "imagenet", input_shape = (120, 120, 3))
    # for layer in xception.layers:
    #     layer.trainable = False
    GAP = tools.add_globalAveragePooling(xception.output)
    dense = Dense_Tools.add_regularizer_kernel_dense(1370, GAP, regularizers.L2(0.1))
    dense = add_Activative(dense)
    dense = add_dropout(dense, Dropout_Coefficient)
    dense = Dense_Tools.add_dense(7, dense)
    output = add_Activative(dense, softmax)

    return xception.input, output

def Add_Activation_in_Xception():
    tools = model_2D_tool()
    Dense_Tools = model_Dense_Layer()

    Xception_input, Xception_output = Xception_indepentment(input_shape = (120, 120, 4))
    conv = tools.add_globalAveragePooling(input = Xception_output)
    dense = Dense_Tools.add_regularizer_kernel_dense(1370, conv, regularizers.L2(0.1))
    dense = add_Activative(dense)
    dense = add_dropout(dense, 0.6)
    dense = Dense_Tools.add_dense(7, dense)
    output = add_Activative(dense, softmax)

    return Xception_input, output