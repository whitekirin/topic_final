from matplotlib import pyplot as plt
import seaborn as sns
import datetime
import os
import matplotlib.figure as figure
import matplotlib.backends.backend_agg as agg
from File_processing.file_processing import judge_file_exist, make_dir, make_save_root

def plot_history(history_value, file_name, model_name):
    plt.figure(figsize=(16,4))
    plt.subplot(1,2,1)
    plt.plot(history_value.history['accuracy'])
    plt.plot(history_value.history['val_accuracy'])
    plt.ylabel('Accuracy')
    plt.xlabel('epoch')
    plt.legend(['Train','Validation'], loc='upper left')
    plt.title('Model Accuracy')

    plt.subplot(1,2,2)
    plt.plot(history_value.history['loss'])
    plt.plot(history_value.history['val_loss'])
    plt.ylabel('loss')
    plt.xlabel('epoch')
    plt.legend(['Train','Validation'], loc='upper left')
    plt.title('Model Loss')

    model_dir = '../../Model_training_image/save_the_train_image( ' + str(datetime.date.today()) + " )"
    if not judge_file_exist(model_dir):
        make_dir(model_dir)
    modelfiles = make_save_root(str(model_name) + " " + str(file_name) + ".png", model_dir)
    plt.savefig(modelfiles)
    plt.close("all")      # 關閉圖表

def draw_heatmap(matrix, model_name, index):
    # 创建热图
    fig = figure.Figure(figsize=(6, 4))
    canvas = agg.FigureCanvasAgg(fig)
    Ax = fig.add_subplot(111)
    sns.heatmap(matrix, annot = True, cmap = "Purples", ax = Ax)#画热力图，cmap表示设定的颜色集

    model_dir = '../../Model_Confusion_matrix/model_matrix_image ( ' + str(datetime.date.today()) + " )"
    if not judge_file_exist(model_dir):
        make_dir(model_dir)
    modelfiles = make_save_root(str(model_name) + "-" + str(index) + ".png", model_dir)

    # confusion.figure.savefig(modelfiles)
    # 设置图像参数
    Ax.set_title(str(model_name) + " confusion matrix")
    Ax.set_xlabel("X-Predict label of the model")
    Ax.set_ylabel("Y-True label of the model")

    # 保存图像到文件中
    canvas.print_figure(modelfiles)