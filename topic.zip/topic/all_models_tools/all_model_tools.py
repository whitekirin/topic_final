from keras.layers import Dropout, Activation
from keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint
from keras.optimizers import Adam, RMSprop, Adagrad, SGD
from keras.models import Model
from keras.layers import GlobalAveragePooling2D, Dense, Reshape, Multiply, add
from keras.activations import relu
from File_processing.file_processing import judgeRoot_makeDir, make_save_root
import datetime
import os

# 總工具

class Change_Status:
    def __init__(self) -> None:
        self.Layer_Output = 0
        pass
    @property   
    def output(self, Layer_Output):
        self.Layer_Output = Layer_Output
    @output.setter
    def output(self, Change_Value):
        self.Layer_Output = Change_Value

def add_dropout(input, drop):
    x = Dropout(drop)(input)
    return x

def add_Activative(input, activative = relu):
    x = Activation(activation = activative)(input)
    return x

def attention_block(input):
    channel = input.shape[-1]

    GAP = GlobalAveragePooling2D()(input)

    block = Dense(units = channel // 16, activation = "relu")(GAP)
    block = Dense(units = channel, activation = "sigmoid")(block)
    block = Reshape((1, 1, channel))(block)

    block = Multiply()([input, block])

    return block

def add_optimizers_function(lr, judge):
    '''
        judge == 1: Adam
        judge == 2: RMSprop
        judge == 3: SGD
        judge == 4: Adagrad
    '''
    if judge == 1:
        x = Adam(learning_rate = lr)
    if judge == 2:
        x = RMSprop(learning_rate = lr)
    if judge == 3:
        x = SGD(learning_rate = lr, momentum = 0.9)
    if judge == 4:
        x = Adagrad(learning_rate = lr)
    return x

def call_back(model_name, index): 
    model_dir = '../../save_the_best_model/Topic/' + model_name
    judgeRoot_makeDir(model_dir)
    modelfiles = make_save_root('best_model( ' + str(datetime.date.today()) + " )-" +  str(index) + ".h5", model_dir)
    
    model_mckp = ModelCheckpoint(modelfiles, monitor='val_loss', save_best_only=True, save_weights_only = True, mode='auto')

    earlystop = EarlyStopping(monitor='val_loss', patience=74, verbose=1) # 提早停止

    reduce_lr = ReduceLROnPlateau(
                        monitor = 'val_loss',
                        factor = 0.94,           # 學習率降低的量。 new_lr = lr * factor
                        patience = 2,                # 沒有改進的時期數，之後學習率將降低
                        verbose = 0,
                        mode = 'auto',
                        min_lr = 0                   # 學習率下限
                    )

    callbacks_list = [model_mckp, earlystop, reduce_lr]
    return callbacks_list