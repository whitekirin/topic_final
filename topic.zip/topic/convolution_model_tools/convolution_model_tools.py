from keras.layers import BatchNormalization, Flatten, GlobalAveragePooling2D, MaxPooling2D

# 捲積層總工具
class model_tools:
    def __init__(self, pool_size, stride, padding):
        self.PoolSize = pool_size
        self.stride = stride
        self.padding = padding
        pass
    def add_batchnomlization(self, input):
        x = BatchNormalization()(input)
        return x
    def add_flatten(self, input):
        x = Flatten()(input)
        return x
    def add_globalAveragePooling(self, input):
        x = GlobalAveragePooling2D()(input)
        return x
    def add_MaxPooling(self, input, poolsize = 0):
        if poolsize != 0:
            self.PoolSize = poolsize
        x = MaxPooling2D(pool_size = self.PoolSize, strides = self.stride, padding = self.padding)(input)
        return x