import keras
from keras.layers import Conv3D
from convolution_model_tools.convolution_model_tools import model_tools

# convolution 3D的工具
class model_3D_tool(model_tools):
    def __init__(self, filters, kernel_size, activative, padding, batch_size):
        super().__init__(filters, kernel_size, activative, padding)
        self.__BatchSize = batch_size
        pass
    def add_3D_input(self, shape = (150 * 150 * 3)): # inputshape格式(寬, 長, 深度, 通道數)
        x = keras.Input(shape = shape, batch_size = self.__BatchSize)
        return x
    def add_Convolution3D(self, input, ConvFilters, stride, KernelSize):
        x = Conv3D(filters = ConvFilters, strides = stride, kernel_size = KernelSize, padding = self.padding)(input)
        return x