from keras.layers import Conv2D, Input, add, Dense, SeparableConv2D, Add
from convolution_model_tools.convolution_model_tools import model_tools
from all_models_tools.all_model_tools import add_Activative

# convolution 2D的工具
class model_2D_tool(model_tools):
    def __init__(self, pool_size = (2, 2), stride = (2, 2), padding = "same"):
        super().__init__(pool_size, stride, padding)
        pass
    def add_2D_input(self, img_size = 120):
        '''
        輸入層，內容: (寬, 長, 通道數)
        '''
        x = Input(shape = (img_size, img_size, 3))
        return x
    def add_Convolution2D(self, input, ConvFilters, Convstride = 1, KernelSize = (3, 3)):
        '''
        加一層convolution
        '''
        x = Conv2D(filters = ConvFilters, strides = (Convstride, Convstride), kernel_size = KernelSize, padding = self.padding)(input)
        return x
    def add_separableConv(self, input, ConvFilters, KernelSize = (3, 3)):
        x = SeparableConv2D(filters = ConvFilters, kernel_size = KernelSize, padding = "same")(input)
        return x
    def add_two_floors_convolution2D(self, input, ConvFilters, Convstride = 1, KernelSize = (3, 3)):
        '''
        加兩層filters相同的convolution
        '''
        x = Conv2D(filters = ConvFilters, strides = Convstride, kernel_size = KernelSize, padding = self.padding)(input)
        x = add_Activative(x)
        x = Conv2D(filters = ConvFilters, strides = Convstride, kernel_size = KernelSize, padding = self.padding)(x)
        return x
    def add_three_floors_convolution2D(self, input, ConvFilters, Convstride = 1, KernelSize = (3, 3)):
        '''
        加兩層filters相同的convolution
        '''
        x = Conv2D(filters = ConvFilters, strides = Convstride, kernel_size = KernelSize, padding = self.padding)(input)
        x = add_Activative(x)
        x = Conv2D(filters = ConvFilters, strides = Convstride, kernel_size = KernelSize, padding = self.padding)(x)
        x = add_Activative(x)
        x = Conv2D(filters = ConvFilters, strides = Convstride, kernel_size = KernelSize, padding = self.padding)(x)
        return x
    def add_four_floors_convolution2D(self, input, ConvFilters, Convstride = 1, KernelSize = (3, 3)):
        '''
        加兩層filters相同的convolution
        '''
        x = Conv2D(filters = ConvFilters, strides = Convstride, kernel_size = KernelSize, padding = self.padding)(input)
        x = add_Activative(x)
        x = Conv2D(filters = ConvFilters, strides = Convstride, kernel_size = KernelSize, padding = self.padding)(x)
        x = add_Activative(x)
        x = Conv2D(filters = ConvFilters, strides = Convstride, kernel_size = KernelSize, padding = self.padding)(x)
        x = add_Activative(x)
        x = Conv2D(filters = ConvFilters, strides = Convstride, kernel_size = KernelSize, padding = self.padding)(x)
        x = add_Activative(x)
        return x
    def add_one_convolution_and_one_BatchNomalization(self, input, ConvFilters, Convstride = 1, KernelSize = (3, 3)):
        '''
        加一層convolution層跟一層BatchNomalization層
        '''
        x = Conv2D(filters = ConvFilters, strides = Convstride, kernel_size = KernelSize, padding = self.padding)(input)
        x = add_Activative(x)
        x = super().add_batchnomlization(x)
        return x
    
    def Dense_residual_block(self, input_tensor, First_units, Sec_units):
        x = Dense(units = First_units)(input_tensor)
        x = add_Activative(x)

        x = Dense(units = Sec_units)(x)
        x = add_Activative(x)
        input_tensor = Dense(units = Sec_units)(input_tensor)

        x = add([x, input_tensor])
        output = add_Activative(x)

        return output
    
    def Convolution_first_residual_block(self, input_tensor, first_filtes, second_filters):
        residual = Conv2D(filters = second_filters, kernel_size = (1, 1), strides = (2, 2), padding = "same")(input_tensor)
        residual = self.add_batchnomlization(input = residual)

        x = SeparableConv2D(filters = first_filtes, kernel_size = (3, 3), padding = "same")(input_tensor)
        x = self.add_batchnomlization(input = x)
        x = add_Activative(input = x)

        x = SeparableConv2D(filters = second_filters, kernel_size = (3, 3), padding = "same")(x)
        x = self.add_batchnomlization(input = x)
        x = self.add_MaxPooling(input = x)

        x = Add()([x, residual])

        return x
    
    def Convolution_second_residual_block(self, input_tensor, first_filtes, second_filters):
        residual = Conv2D(filters = second_filters, kernel_size = (1, 1), strides = (2, 2), padding = "same")(input_tensor)
        residual = self.add_batchnomlization(input = residual)

        x = add_Activative(input = input_tensor)
        x = SeparableConv2D(filters = first_filtes, kernel_size = (3, 3), padding = "same")(x)
        x = self.add_batchnomlization(input = x)

        x = add_Activative(input = x)
        x = SeparableConv2D(filters = second_filters, kernel_size = (3, 3), padding = "same")(x)
        x = self.add_batchnomlization(input = x)
        x = self.add_MaxPooling(input = x)

        x = Add()([x, residual])

        return x
    
    def Middle_Flow_residual_block(self, input_tensor, filtes):
        x = add_Activative(input = input_tensor)
        x = SeparableConv2D(filters = filtes, kernel_size = (3, 3), padding = "same")(x)
        x = self.add_batchnomlization(input = x)

        x = add_Activative(input = x)
        x = SeparableConv2D(filters = filtes, kernel_size = (3, 3), padding = "same")(x)
        x = self.add_batchnomlization(input = x)

        x = add_Activative(input = x)
        x = SeparableConv2D(filters = filtes, kernel_size = (3, 3), padding = "same")(x)
        x = self.add_batchnomlization(input = x)

        x = Add()([x, input_tensor])

        return x