from keras.layers import Dense
from all_models_tools.all_model_tools import add_Activative

class model_Dense_Layer:
    def __init__(self):
        pass
    def add_dense(self, unit, input_data):
        x = Dense(units = unit)(input_data)
        return x
    def add_regularizer_kernel_dense(self, unit, input_data, regularizer):
        x = Dense(units = unit, kernel_regularizer = regularizer)(input_data)
        return x
    def add_regularizer_bias_dense(self, unit, input_data,  regularizer):
        x = Dense(units = unit, bias_regularizer = regularizer)(input_data)
        return x