from experiments.original_image_model import original_VGG19_model, original_Resnet50_model, original_InceptionResNetV2_model, original_Xception_model, original_EfficientNetV2L_model, original_DenseNet169_model
from keras.applications import ResNet50
import cv2
import numpy as np
import os
import datetime
from keras import Model

class testing:
    def __init__(self) -> None:
        # self.getFileData_root = "../../Dataset/Topic/TestData/monkeypox28.png"
        pass
    def process_main(self):
        # image = self.load_testing_data(self.getFileData_root)
        # image = self.image_data_processing(image)

        cnn_model = self.construct_model() # 呼叫讀取模型的function
        print(cnn_model.summary())
                
        # model_dir = "../../save the best final model/Topic/Xception//best_model.h5" # 這是一個儲存模型權重的路徑，每一個模型都有一個自己權重儲存的檔
        # if os.path.exists(model_dir): # 如果這個檔案存在
        #     cnn_model.load_weights(model_dir) # 將模型銓重讀出來
        
        # result_image, result = self.return_predicted_result(cnn_model, image)
        # print("Original: MonkeyPox")
        # print("Predict : ", result_image, " ", result, " % ")

        pass
    def load_testing_data(self, root):
        img_size = 120 # 縮小後的影像
        try:
            image = cv2.imread(root, cv2.IMREAD_COLOR) # 讀檔
            resized_image = cv2.resize(image, (img_size, img_size)) # 濤整圖片大小
        except Exception as e:
            print(e)

        return np.array(resized_image)
    
    def image_data_processing(self, data):
        '''讀檔後處理圖片'''
        img_size = 120
        data = np.asarray(data).astype(np.float32) # 將圖list轉成np.array
        # data = data / 255                     # 標準化影像資料
        data = data.reshape(-1, img_size, img_size, 3)  # 更改陣列形狀

        return data
    
    def construct_model(self):
        '''決定我這次訓練要用哪個model'''
        # model_input, output = find_example_cnn_model()
        # model_input, output = Increasing_model()
        # model_input, output = VGG19_model()
        model_input, output = Resnet50_model()
        # model_input, output = NASNetLarge_model()
        # model_input, output = DenseNet201_model()

        # model_input, output = original_VGG19_model()
        # model_input, output = original_Resnet50_model()
        # model_input, output = original_InceptionResNetV2_model()
        # model_input, output = original_Xception_model()
        # model_input, output = original_DenseNet169_model()
        # model_input, output = original_EfficientNetV2L_model()
        cnn_model = Model(inputs = model_input.input, outputs = output)
        return cnn_model

    def return_predicted_result(self, cnn_model : Model, image):
        result = cnn_model.predict(image)
        result_int = np.argmax(result, axis = 1)  # 將預測出來的結果從one-hot encoding轉成label-encoding

        if result_int == 0:
            return "BP", result[0]
        if result_int == 1:
            return "PF", result[1]
        if result_int == 2:
            return "PV", result[2]
        if result_int == 3:
            return "Chickenpox", result[3]
        if result_int == 4:
            return "monkey_pox", result[4]
        if result_int == 5:
            return "normal", result[5]
        if result_int == 6:
            return "Abnormal", result[6]
        

t = testing()
t.process_main()


import threading
from firebase_admin import credentials, firestore
import firebase_admin
import time

# 初始化firebase的狀態
firCredentials = credentials.Certificate("topic-71bec-50398f11c5cf.json") # 將秘鑰取出
firebase_admin.initialize_app (firCredentials) # 初始化我的app

# 啟動firebase
db = firestore.client()

delete_done = threading.Event() # 觸發執行事件
def on_snapshot(col_snapshot, changes, read_time):
    for change in changes:     
        if change.type.name == "MODIFIED": # 資料有被修改就執行
            print(f"修改的帳號: {change.document.id}") # 輸出被修改的id
            total_data = db.collection('plt').document(change.document.id)
            doc = total_data.get().to_dict() # 取出該id下的所有資料並轉呈dict的資料型態
            print(doc["profile_picture_url"]) # 輸出上傳的圖片路徑

doc_ref = db.collection('plt')
query_watch = doc_ref.on_snapshot(on_snapshot)

# 持續運行
while True:
    time.sleep(1)
    print('processing...')