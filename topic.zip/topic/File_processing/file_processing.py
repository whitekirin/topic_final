import os
import cv2
import sys
import datetime
import pandas as pd

def judgeRoot_makeDir(file_root):
    if judge_file_exist(file_root):
       return True
    else:
        make_dir(file_root)
        return False

def judge_file_exist(file_root):
    if not os.path.exists(file_root): # 若路徑不存在的話
        return False # 回傳True
    else:
        return True # 回傳False
    
def make_dir(file_root):
    os.makedirs(file_root)

def make_save_root(FileName, File_root):
    return os.path.join(File_root, FileName)

def save_dir(FileName, save_root, image):
    # 存.npy檔
    # image_processing = Read_image_and_Process_image()
    # image = image_processing.shapen(image)
    # np.save(save_root, image)
        
    # 存.png檔
    save_root = make_save_root(FileName, save_root)
    cv2.imwrite(save_root, image)

def save_CSV_file(file_name, data : pd.DataFrame):
    '''儲存訓練結果'''
    model_dir = '../../Model_training_result/save_the_train_result(' + str(datetime.date.today()) + ")" # 儲存的檔案路徑，由save_the_train_result + 當天日期
    judgeRoot_makeDir(model_dir)
    modelfiles = make_save_root(file_name + ".csv", model_dir)  # 將檔案名稱及路徑字串合併成完整路徑
    data.to_csv(modelfiles, mode = "a")