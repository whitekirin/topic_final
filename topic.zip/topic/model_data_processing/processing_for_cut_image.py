from model_data_processing.processing import shuffle_data
from initialization.img_initialization import init_cut_image
from Read_and_process_image.ReadAndProcess import Read_image_and_Process_image
from sklearn.model_selection import train_test_split
from loadData_and_MakeImageGenerator.LoadData import Loding_Data_Root
from _validation.ValidationTheEnterData import validation_the_enter_data
from merge_class.merge import merge


class file_image_cut(init_cut_image):
    def __init__(self):
        '''
        影像切割物件
        label有7類,會將其轉成one-hot-encoding的形式
            [1, 0, 0, 0, 0, 0, 0] = BP
            [0, 1, 0, 0, 0, 0, 0] = PF
            [0, 0, 1, 0, 0, 0, 0] = PV
            [0, 0, 0, 1, 0, 0, 0] = monkey pox
            [0, 0, 0, 0, 1, 0, 0] = Chickenpox
            [0, 0, 0, 0, 0, 1, 0] = normal
            [0, 0, 0, 0, 0, 0, 1] = abnormal
        '''
        super().__init__()
        self.merge = merge()

        pass

    def process_main(self, Test_data_root = "../../Dataset/Topic/TestData", Validation_data_root = "../../Dataset/Topic/ValidationData"):
        self.testSize = 21
        self.test, self.test_label = self.get_Independent_image(Test_data_root, "test")
        print("\ntest_labels有" + str(len(self.test_label)) + "筆資料\n")

        self.testSize = 9
        self.validation, self.validation_label = self.get_Independent_image(Validation_data_root)
        print("\nvalidation_labels有 " + str(len(self.validation_label)) + " 筆資料\n")

    def get_Independent_image(self, independent_DataRoot, judge = "validation"):
        load = Loding_Data_Root()
        image_processing = Read_image_and_Process_image()
        _validation = validation_the_enter_data()

        if _validation.validation_string(judge, "test"):
            classify_image = super().get_category_data() # 取得分類的類別，並做成一個dict

            herpes_root, monkeypox_root, abnormal_root = load.load_Independent_data(independent_DataRoot, self.testSize) # 讀取測試資料集的資料
            herpes_root, monkeypox_root, abnormal_root = self.get_another_data(herpes_root, monkeypox_root, abnormal_root)

            # Abnormal = []
            # for i in range(self.testSize): # 讀原始資料，所以異常資料及只要200張
            #     Abnormal.append(abnormal_root[i])

            herpes_root = super().get_classify_img(1, herpes_root) # 將讀出來的資製作成一個herpes的list
            monkeypox_root = super().get_classify_img(2, monkeypox_root) # 將讀出來的資製作成一個monkeypox的list

            class_num = self.get_data_label() # 取得label轉成one-hot之後的類別
            
            total_img_root = herpes_root + monkeypox_root + [abnormal_root] # 合併路徑
            # total_img_root = monkeypox_root # 合併路徑
        else: # 若路徑包含paper的字串，表示這是處理paper資料的路徑， 沒有則不是
            classify_image = super().get_category_data() # 取得分類的類別，並做成一個dict
            herpes_root, monkeypox_root, abnormal_root = load.load_Independent_data(independent_DataRoot, self.testSize) # 讀取測試資料集的資料
            
            # Abnormal = []
            # for i in range(self.testSize): # 讀原始資料，所以異常資料及只要200張
            #     Abnormal.append(abnormal_root[i])

            herpes_root = super().get_classify_img(1, herpes_root) # 將讀出來的資製作成一個herpes的list
            monkeypox_root = super().get_classify_img(2, monkeypox_root) # 將讀出來的資製作成一個monkeypox的list

            class_num = self.get_data_label() # 取得label轉成one-hot之後的類別
            
            total_img_root = herpes_root + monkeypox_root + [abnormal_root] # 合併路徑
            # total_img_root = monkeypox_root # 合併路徑
            
        
        test_label = []
        i = 0 # 計算classify_image的counter，且計算總共有幾筆資料
        for test_title in total_img_root: # 藉由讀取所有路徑來進行讀檔
            test_label = image_processing.make_label_list(len(test_title), class_num[i]) # 製作對應圖片數量的label出來+    
            print("classify" + str(i) + " 有 " + str(len(test_label)) + " 筆資料 ")

            classify_image[i] = test_title
            classify_image[i + 7] = test_label
            i += 1

        original_test_root = self.merge.merge_data_main(classify_image, 0, 7)
        test_label = self.merge.merge_data_main(classify_image, 7, 7)

        shuffle_images, shuffle_label = shuffle_data(original_test_root, test_label)

        test = []
        for shuffle_image in shuffle_images:
            test.append(image_processing.get_data(shuffle_image)) # 讀檔
        test, test_label = image_processing.image_data_processing(test, shuffle_label)
        test = image_processing.normalization(test)

        return test, test_label
    
    def get_data_label(self, judge = 1):
        if judge == 1:
            return [[1, 0, 0, 0, 0, 0, 0], [0, 1, 0, 0, 0, 0, 0], [0, 0, 1, 0, 0, 0, 0], [0, 0, 0, 1, 0, 0, 0], [0, 0, 0, 0, 1, 0, 0], [0, 0, 0, 0, 0, 1, 0], [0, 0, 0, 0, 0, 0, 1]]
        if judge == 2:
            return [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]

    def cut_data(self, data, label, TestSize = 0.2, random = 2022):
        '''切割資料集'''
        train, test, train_label, test_label = train_test_split(data, label, test_size = TestSize, random_state = random)
        return (train, test, train_label, test_label)

    def get_train_data(self, process_data):
        '''切割出驗證資料'''
        merge_data = [process_data["classify_label1"], process_data["classify_label2"], process_data["classify_label3"]]
        train = self.merge.merge_data_main(process_data, 0)
        train_label = self.merge.merge_data_main(merge_data, 0)

        return train, train_label
    
    def get_another_data(self, herpes_root, monkeypox_root, abnormal_root):
        herpes_root.bp.append("../../Dataset/Topic/TestData/data/bp/DSC_1908.JPG")
        herpes_root.pf.append("../../Dataset/Topic/TestData/data/pf/DSC_359.JPG")
        herpes_root.pv.append("../../Dataset/Topic/TestData/data/pv/DSC_685.JPG")
        monkeypox_root.Chickenpox.append("../../Dataset/Topic/TestData/data/chickenpox/chickenpox30.png")
        monkeypox_root.monkey_pox.append("../../Dataset/Topic/TestData/data/monkeypox/monkeypox249.png")
        monkeypox_root.normal.append("../../Dataset/Topic/TestData/data/normal/48.png")
        abnormal_root.append("../../Dataset/Topic/TestData/data/abnormal/5_25.jpg")

        return herpes_root, monkeypox_root, abnormal_root
        