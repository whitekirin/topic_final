'''
processing 這個檔案是我處理資料用的套件，以下為套件說明

get_data(data_dir, label, index):
    取得檔案中的資料。
    data_dir：檔案路徑
    label : 標籤名稱
    index : 標籤名稱轉成數字
'''