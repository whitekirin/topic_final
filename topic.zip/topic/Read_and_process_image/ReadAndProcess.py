import cv2
import numpy as np
from keras.preprocessing.image import ImageDataGenerator


class Read_image_and_Process_image:
    def __init__(self) -> None:
        pass
    def get_data(self, path):
        '''讀檔'''
        img_size = 120 # 縮小後的影像
        try:
            img_arr = cv2.imread(path, cv2.IMREAD_COLOR) # 讀檔(彩色)
            # img_arr = cv2.imread(path, cv2.IMREAD_GRAYSCALE) # 讀檔(灰階)
            resized_arr = cv2.resize(img_arr, (img_size, img_size)) # 濤整圖片大小
        except Exception as e:
            print(e)
        
        return resized_arr
    
    def Data_Augmentation_Image(self, path):
        resized_arr = []

        for p in path:
            img_size = 120 # 縮小後的影像
            try:
                img_arr = cv2.imread(p, cv2.IMREAD_COLOR) # 讀檔(彩色)
                # img_arr = cv2.imread(path, cv2.IMREAD_GRAYSCALE) # 讀檔(灰階)
                resized_arr.append(cv2.resize(img_arr, (img_size, img_size))) # 濤整圖片大小
            except Exception as e:
                print(e)
        
        return np.array(resized_arr)

    def image_data_processing(self, data, label):
        '''讀檔後處理圖片'''
        img_size = 120
        data = np.asarray(data).astype(np.float32) # 將圖list轉成np.array
        data = data.reshape(-1, img_size, img_size, 3)  # 更改陣列形狀
        label = np.array(label)                         # 將label從list型態轉成 numpy array
        return data, label
    
    def normalization(self, images):
        imgs = []
        for img in images:
            img = np.asarray(img).astype(np.float32) # 將圖list轉成np.array
            img = img / 255                     # 標準化影像資料
            imgs.append(img)

        return np.array(imgs)
    
    # def load_numpy_data(self, file_names):
    #     '''載入numpy圖檔，並執行影像處理提高特徵擷取'''
    #     i = 0
    #     numpy_image = []
    #     original_image = []
    #     for file_name in file_names:
    #         compare = str(file_name).split(".")
    #         if compare[-1] == "npy":
    #             image = np.load(file_name) # 讀圖片檔
    #             numpy_image.append(image) # 合併成一個陣列
    #         else:
    #             original_image.append(file_name)

    #     original_image = self.get_data(original_image)

    #     for file in original_image:
    #         numpy_image.append(file)
            
    #     return numpy_image
    
    def calculate_label(self, data, total_label, judge = 1):
        if judge == 1:
            data_labels = ["classify1", "classify2", "classify3"]
            label = ["classify_label1", "classify_label2", "classify_label3"]
        else:
            data_labels = ["classify1"]
            label = ["classify_label1"]

        for i in range(len(data_labels)):
            length = (len(data[data_labels[i]])) # 取得這個dict中每個類別有多少資料
            data[label[i]] = self.make_label_list(length, total_label[i]) # 藉由這些資料去算出對應數量的label

        return data

    def make_label_list(self, length, content):
        '''製作label的列表'''
        label_list = []
        for i in range(length):
            label_list.append(content)
        return label_list
    
    def data_enhancement(self, judge): # 影像資料增強
        '''
        ImageGenerator的參數:
            featurewise_center : 布爾值。將輸入數據的均值設置為0，逐特徵進行。
            samplewise_center : 布爾值。將每個樣本的均值設置為0。
            featurewise_std_normalization : Boolean. 布爾值。將輸入除以數據標準差，逐特徵進行。
            samplewise_std_normalization : 布爾值。將每個輸入除以其標準差。
            zca_epsilon : ZCA 白化的epsilon 值，默認為1e-6。
            zca_whitening : 布爾值。是否應用ZCA 白化。
            rotation_range : 整數。隨機旋轉的度數範圍。
            width_shift_range : 浮點數、一維數組或整數
                float: 如果<1，則是除以總寬度的值，或者如果>=1，則為像素值。
                1-D 數組: 數組中的隨機元素。
                int: 來自間隔 (-width_shift_range, +width_shift_range) 之間的整數個像素。
                width_shift_range=2時，可能值是整數[-1, 0, +1]，與 width_shift_range=[-1, 0, +1] 相同；而 width_shift_range=1.0 時，可能值是 [-1.0, +1.0) 之間的浮點數。
            height_shift_range : 浮點數、一維數組或整數
                float: 如果<1，則是除以總寬度的值，或者如果>=1，則為像素值。
                1-D array-like: 數組中的隨機元素。
                int: 來自間隔 (-height_shift_range, +height_shift_range) 之間的整數個像素。
                height_shift_range=2時，可能值是整數[-1, 0, +1]，與 height_shift_range=[-1, 0, +1] 相同；而 height_shift_range=1.0 時，可能值是 [-1.0, +1.0) 之間的浮點數。
            shear_range : 浮點數。剪切強度（以弧度逆時針方向剪切角度）。
            zoom_range : 浮點數或[lower, upper]。隨機縮放範圍。如果是浮點數，[lower, upper] = [1-zoom_range, 1+zoom_range]。
            channel_shift_range : 浮點數。隨機通道轉換的範圍。
            fill_mode : {"constant", "nearest", "reflect" or "wrap"} 之一。默認為'nearest'。輸入邊界以外的點根據給定的模式填充：
                'constant': kkkkkkkk|abcd|kkkkkkkk (cval=k)
                'nearest': aaaaaaaa|abcd|dddddddd
                'reflect': abcddcba|abcd|dcbaabcd
                'wrap': abcdabcd|abcd|abcdabcd
            cval : 浮點數或整數。用於邊界之外的點的值，當 fill_mode = "constant" 時。
            horizontal_flip : 布爾值。隨機水平翻轉。
            vertical_flip : 布爾值。隨機垂直翻轉。
            rescale : 重縮放因子。默認為None。如果是None 或0，不進行縮放，否則將數據乘以所提供的值（在應用任何其他轉換之前）。
            preprocessing_function : 應用於每個輸入的函數。這個函數會在任何其他改變之前運行。這個函數需要一個參數：一張圖像（秩為3 的Numpy 張量），並且應該輸出一個同尺寸的Numpy 張量。
            data_format : 圖像數據格式，{"channels_first", "channels_last"} 之一。"channels_last" 模式表示圖像輸入尺寸應該為(samples, height, width, channels)，"channels_first" 模式表示輸入尺寸應該為(samples, channels, height, width)。默認為在Keras 配置文件 ~/.keras/keras.json 中的 image_data_format 值。如果你從未設置它，那它就是"channels_last"。
            validation_split : 浮點數。Float. 保留用於驗證的圖像的比例（嚴格在0和1之間）。
            dtype : 生成數組使用的數據類型。
        '''
        if judge == 1:
            datagen  = ImageDataGenerator(
                        rotation_range=30,          # 旋轉影像
                        width_shift_range=0.1,      # 圖像隨機水平移動，位移距離為圖像長度乘以參數(0.1)
                        height_shift_range=0.1,     # 圖像隨機垂直移動，位移距離為圖像長度乘以參數(0.1)
                        zoom_range=0.2,             # 隨機縮放範圍，[lower, upper] = [1-zoom_range, 1+zoom_range]   
                        horizontal_flip=False,      # 水平翻轉
                        vertical_flip=False,        # 垂直翻轉
                        fill_mode='nearest'         # 在旋轉或平移造成空隙時，則空隙補常數
                    )
        if judge == 2:
            datagen  = ImageDataGenerator(
                        rotation_range=180,
                        width_shift_range=0.2,
                        height_shift_range=0.1,
                        zoom_range=0.1,
                        horizontal_flip=True,
                        vertical_flip=True,
                        fill_mode='nearest'
            )
        if judge == 3:
            datagen = ImageDataGenerator(rescale = 1 / 255)
        
        if judge == 4: # 第二份paper的資料強化
            datagen = ImageDataGenerator(
                rotation_range=50,          # 旋轉影像
                width_shift_range=0.2,      # 圖像隨機水平移動，位移距離為圖像長度乘以參數(0.1)
                height_shift_range=0.2,     # 圖像隨機垂直移動，位移距離為圖像長度乘以參數(0.1)
                shear_range = 0.25,
                zoom_range=0.1,             # 隨機縮放範圍，[lower, upper] = [1-zoom_range, 1+zoom_range]
                channel_shift_range = 20    # 隨機通道轉換的範圍
            )

        if judge == 5: # 第一份paper的資料強化
            datagen = ImageDataGenerator(
                rotation_range=45,          # 旋轉影像
                width_shift_range=0.02,      # 圖像隨機水平移動，位移距離為圖像長度乘以參數(0.1)
                height_shift_range=0.02,     # 圖像隨機垂直移動，位移距離為圖像長度乘以參數(0.1)
                shear_range = 0.02,
                zoom_range=0.02,             # 隨機縮放範圍，[lower, upper] = [1-zoom_range, 1+zoom_range]
                horizontal_flip = True,
                fill_mode = "reflect"
            )
        return datagen
    
    def get_one_hot_label(self, judge = 1):
        if judge == 1:
            herpes_class_num = [[1, 0, 0, 0, 0, 0, 0], [0, 1, 0, 0, 0, 0, 0], [0, 0, 1, 0, 0, 0, 0]]
            monkeypox_class_num = [[0, 0, 0, 1, 0, 0, 0], [0, 0, 0, 0, 1, 0, 0], [0, 0, 0, 0, 0, 1, 0]]
            abnormal_class_num = [[0, 0, 0, 0, 0, 0, 1]]
            return herpes_class_num, monkeypox_class_num, abnormal_class_num
        if judge == 2:
            monkeypox_class_num = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]
            return monkeypox_class_num