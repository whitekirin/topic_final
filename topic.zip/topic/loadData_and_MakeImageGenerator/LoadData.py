from initialization.process_initialization import incoming_Herpes_parameters, incoming_MonkeyPox_parameters, incoming_generator_data
from _validation.ValidationTheEnterData import validation_the_enter_data
from model_data_processing.processing import sparate_fixed_data, shuffle_data
from merge_class.merge import merge
import os
import glob

class Loding_Data_Root:
    def __init__(self):
        self.__herpe = incoming_Herpes_parameters()
        self.__MonkeyPox = incoming_MonkeyPox_parameters()
        self._validation = validation_the_enter_data()
        self.merge = merge()

        # 製作傳入label
        self.MonKeyPoxlabels = self.get_MonkeyPox_labels()
        self.Herpeslabels = self.get_herpes_labels()

        # 將資料合併成一個list(初始化，裡面資料是空的)
        self.MonkeyPox_data = self.get_MonkeyPox_data()
        self.Herpes_data = self.get_herpes_data()
        pass

    def process_main(self):
        read_Herpes_data, read_monkeyPox_data = self.__herpe, self.__MonkeyPox
        
        get_MonkeyPox_image_data = self.get_content_dic(self.MonKeyPoxlabels, self.MonkeyPox_data)
        get_Herpes_image_data = self.get_content_dic(self.Herpeslabels, self.Herpes_data)
        get_abnormal_image_data = self.get_content_dic(["abnormal"], [[]], False) # 將異常資料包成一個dict

        generator_data = incoming_generator_data(self.Herpeslabels, self.MonKeyPoxlabels, get_MonkeyPox_image_data, get_Herpes_image_data, get_abnormal_image_data) # 將資料合併成一個class
        generator_data.choose_generator_save_root() # 現在要用的是Topic資料夾中的資料強化的資料

        get_Herpes_original_image_data, get_Herpes_balances_image_data, get_Herpes_myself_image_data = self.get_herpes_data_roots(generator_data.orignal_herpes_dataRoot, generator_data.myself_root, generator_data.original_balance_herpes_dataRoot)
        get_Herpes_image_data = self.merge.merge_dict_to_dict(get_Herpes_original_image_data, get_Herpes_myself_image_data, get_Herpes_balances_image_data)
        
        # 取得Abnormal原始資料集、兩個資料擴增的資料集
        get_Abnormal_original_image_data = self.get_data_root(generator_data.original_abnormal_dataRoot, get_abnormal_image_data, ["abnormal"], 2)            
        # get_abnormal_image_data = get_Abnormal_original_image_data["abnormal"]
         
        # 取得MonkeyPox原始資料集、兩個資料擴增的資料集
        get_monkeypox_original_image_data, get_monkeypox_myself_image_data = self.get_monkeypox_data_roots(generator_data.original_monkeyPox_dataRoot, generator_data.myself_root)
        get_MonkeyPox_image_data = self.merge.merge_dict_to_dict(get_monkeypox_original_image_data, get_monkeypox_myself_image_data)

        sparate = 10000
        read_Herpes_data, read_monkeyPox_data, read_abnormal_data = self.get_fixed_data(get_Herpes_image_data, get_MonkeyPox_image_data, get_Abnormal_original_image_data, sparate)

        return read_Herpes_data, read_monkeyPox_data, read_abnormal_data

    def load_Independent_data(self, load_data_root, scale):
        read_monkeyPox_data = self.__MonkeyPox
        read_Herpes_data = self.__herpe

        get_MonkeyPox_image_data = self.get_content_dic(self.MonKeyPoxlabels, self.MonkeyPox_data)
        get_MonkeyPox_all_image_data = self.get_data_root(load_data_root, get_MonkeyPox_image_data, self.MonKeyPoxlabels)
            
        get_Herpes_image_data = self.get_content_dic(self.Herpeslabels, self.Herpes_data)
        get_Herpes_test_image_data = self.get_data_root(load_data_root, get_Herpes_image_data, self.Herpeslabels)

        get_Abnormal_image_data = {"abnormal" : []}
        get_Abnormal_test_image_data = self.get_data_root(load_data_root, get_Abnormal_image_data, ["abnormal"])

        read_Herpes_data, read_monkeyPox_data, read_Abnormal_data = self.get_fixed_data(get_Herpes_test_image_data, get_MonkeyPox_all_image_data, get_Abnormal_test_image_data, scale)

        return read_Herpes_data, read_monkeyPox_data, read_Abnormal_data
        
    def load_original_image(self): # 讀取原始資料集
        read_monkeyPox_data = self.__MonkeyPox
        read_Herpes_data = self.__herpe

        get_herpes_data = self.get_content_dic(self.Herpeslabels, self.Herpes_data)
        get_abnormal_image_data = {"abnormal" : []}
        get_MonkeyPox_image_data = self.get_content_dic(self.MonKeyPoxlabels, self.MonkeyPox_data)

        generator_data = incoming_generator_data(self.Herpeslabels, self.MonKeyPoxlabels, get_MonkeyPox_image_data, get_herpes_data, get_abnormal_image_data) # 將資料合併成一個class

        get_Herpes_original_image_data = self.get_data_root(generator_data.orignal_herpes_dataRoot, get_herpes_data, self.Herpeslabels)
        get_Abnormal_original_image_data = self.get_data_root(generator_data.original_abnormal_dataRoot, get_abnormal_image_data, ["abnormal"], 2)
        get_MonkeyPox_original_image_data = self.get_data_root(generator_data.original_monkeyPox_dataRoot, get_MonkeyPox_image_data, self.MonKeyPoxlabels)

        read_Herpes_data, read_monkeyPox_data, read_abnormal_data = self.return_classify_data(get_Herpes_original_image_data, get_MonkeyPox_original_image_data, get_Abnormal_original_image_data)
        
        original_abnormal = []
        for i in range(200):
            original_abnormal.append(read_abnormal_data[i])
        read_abnormal_data = original_abnormal

        return read_Herpes_data, read_monkeyPox_data, read_abnormal_data

    def get_herpes_data_roots(self, original_roots, myself_data_root, balances_data_roots, judge = True):
        get_Herpes_image_data = []
        if judge: # 取資料增強後的資料
            # 將水痘資料包成一個dict再包成list
            get_Herpes_image_data = self.craete_data_list(3, get_Herpes_image_data, self.Herpeslabels) # 一個list，裡面存放的是dict，為了用來分開每個資料集的內容

            # 取得Herpes原始資料集、兩個資料擴增的資料集
            get_Herpes_original_image_data = self.get_data_root(original_roots, get_Herpes_image_data[0], self.Herpeslabels)
            get_Herpes_balances_image_data = self.get_data_root(balances_data_roots, get_Herpes_image_data[1], self.Herpeslabels)
            get_Herpes_myself_image_data = self.get_data_root(myself_data_root, get_Herpes_image_data[2], self.Herpeslabels)
            return get_Herpes_original_image_data, get_Herpes_balances_image_data, get_Herpes_myself_image_data
        else: # 取原始資料的資料
            get_Herpes_image_data = self.craete_data_list(1, get_Herpes_image_data) # 以個list，裡面存放的是dict，為了用來分開每個資料集的內容
            get_Herpes_original_image_data = self.get_data_root(original_roots, get_Herpes_image_data, self.Herpeslabels)
            return get_Herpes_original_image_data
    
    def get_monkeypox_data_roots(self, original_roots, myself_data_root):
        get_monkeypox_images_data = []
        get_monkeypox_images_data = self.craete_data_list(2, get_monkeypox_images_data, self.MonKeyPoxlabels) # 以個list，裡面存放的是dict，為了用來分開每個資料集的內容
        # 將猴痘資料包成一個dict再包成list

        get_MonkeyPox_original_image_data = self.get_data_root(original_roots, get_monkeypox_images_data[0], self.MonKeyPoxlabels)
        get_MonkeyPox_myself_image_data = self.get_data_root(myself_data_root, get_monkeypox_images_data[1], self.MonKeyPoxlabels)  

        return get_MonkeyPox_original_image_data, get_MonkeyPox_myself_image_data

    def craete_data_list(self, many, List : list, label):
        for i in range(many):
            List.append(self.get_content_dic(label, [[], [], []]))

        return List

    def get_herpes_labels(self):
        '''取得herpes的label'''
        return ["BP", "PF", "PV"] # 分類標籤
        
    def get_MonkeyPox_labels(self):
        '''取得monkeypox的label'''
        return ["Chickenpox", "Monkeypox", "Normal"] # [水痘，猴痘，正常]

    def get_herpes_data(self):
        return [self.__herpe.bp, self.__herpe.pf, self.__herpe.pv]

    def get_MonkeyPox_data(self):
        return [self.__MonkeyPox.Chickenpox, self.__MonkeyPox.monkey_pox, self.__MonkeyPox.normal]

    def get_content_dic(self, label_name : list, read_data : list, judge = True) -> dict:
        '''儲存成一個dic並回傳'''
        if judge:
            get_image_root = {
            label_name[0] : read_data[0],
            label_name[1] : read_data[1],
            label_name[2] : read_data[2]
            }
        else:
            get_image_root = {label_name[0] : read_data[0]}

        return get_image_root

    def get_data_root(self, root, data_dict, classify_label, judge = 1) -> dict :
        '''取得資料路徑'''
        for label in classify_label:
            if judge == 1:
                path = os.path.join(root, label, "*")
            else:
                path = os.path.join(root, "*")
            path = glob.glob(path)
            data_dict[label] = path
        return data_dict

    def reconvery_data(self, dic_data, incoming_data):
        if self._validation.validation_type(incoming_data, incoming_MonkeyPox_parameters):
            incoming_data.Chickenpox = dic_data["Chickenpox"]
            incoming_data.monkey_pox = dic_data["Monkeypox"]
            incoming_data.normal = dic_data["Normal"]
            return incoming_data
        
        if self._validation.validation_type(incoming_data, incoming_Herpes_parameters):
            incoming_data.bp = dic_data["BP"]
            incoming_data.pf = dic_data["PF"]
            incoming_data.pv = dic_data["PV"]
            return incoming_data
        
        if self._validation.validation_type(dic_data, dict):
            key = list(dic_data.keys())
            return dic_data[key[0]]
        
    def merge_classify_content(self):
        pass
    
    # def get_shuffle_image(self, images, labels):
    #     if len(labels) == 1:
    #         return_images = self.get_content_dic(labels, [[]], False)
    #     else:
    #         return_images = self.get_content_dic(labels, [[], [], []])

    #     for label in labels:
    #         return_images[label].append(shuffle_data(images[label], [], 2))

    def get_fixed_data(self, get_Herpes_test_image_data, get_MonkeyPox_all_image_data, get_Abnormal_test_image_data, scale):
        sparate_herpes_data = shuffle_data(get_Herpes_test_image_data, self.Herpeslabels, 2)
        sparate_monkeypox_data = shuffle_data(get_MonkeyPox_all_image_data, self.MonKeyPoxlabels, 2)
        sparate_abnormal_data = shuffle_data(get_Abnormal_test_image_data, ["abnormal"], 2)

        sparate_herpes_data = sparate_fixed_data(scale, 1, sparate_herpes_data, self.Herpeslabels)
        sparate_monkeypox_data = sparate_fixed_data(scale, 1, sparate_monkeypox_data, self.MonKeyPoxlabels)
        sparate_abnormal_data = sparate_fixed_data(scale, 1, sparate_abnormal_data, ["abnormal"])

        return self.return_classify_data(sparate_herpes_data, sparate_monkeypox_data, sparate_abnormal_data)
    
    def return_classify_data(self, get_Herpes_test_image_data, get_MonkeyPox_all_image_data, get_Abnormal_test_image_data):
        read_monkeyPox_data = self.__MonkeyPox
        read_Herpes_data = self.__herpe

        read_Herpes_data = self.reconvery_data(get_Herpes_test_image_data, read_Herpes_data)
        read_monkeyPox_data = self.reconvery_data(get_MonkeyPox_all_image_data, read_monkeyPox_data)
        read_Abnormal_data = self.reconvery_data(get_Abnormal_test_image_data, None)

        return read_Herpes_data, read_monkeyPox_data, read_Abnormal_data