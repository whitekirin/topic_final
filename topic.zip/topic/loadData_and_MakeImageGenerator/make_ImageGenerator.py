from initialization.process_initialization import incoming_generator_data
from Read_and_process_image.ReadAndProcess import Read_image_and_Process_image
from _validation.ValidationTheEnterData import validation_the_enter_data
from File_processing.file_processing import judgeRoot_makeDir, make_save_root, save_dir
import sys

class Image_generator:
    '''製作資料強化'''
    def __init__(self, generator_data : incoming_generator_data, judge = 1) -> None:
        self._validation = validation_the_enter_data()
        generator_data.choose_generator_save_root(judge)
        self.Augmentation_image_save_root = generator_data.myself_root
        self.augmentation_image_labels = generator_data.monkeyPox_label
        self.stop = 2900
        data_size = 0

        # 製作標準資料增強
        '''
            這裡我想要做的是依照paper上的資料強化IMAGE DATA COLLECTION AND IMPLEMENTATION OF DEEP LEARNING-BASED MODEL IN DETECTING MONKEYPOX DISEASE USING MODIFIED VGG16
            產生出資料強化後的影像
        '''
        print("\nAugmentation one monkeypox image")
        data_size = self.get_processing_Augmentation(generator_data.monkeyPox_dic, 1, data_size)

        # 製作標準資料增強
        '''
            這裡我想要做的是依照paper上的資料強化IMAGE DATA COLLECTION AND IMPLEMENTATION OF DEEP LEARNING-BASED MODEL IN DETECTING MONKEYPOX DISEASE USING MODIFIED VGG16
            產生出資料強化後的影像
        '''
        print("\nAugmentation two monkeypox image")
        data_size = self.get_processing_Augmentation(generator_data.monkeyPox_dic, 2, data_size)

        # 製作標準資料增強
        '''
            這裡我想要做的是依照paper上的資料強化IMAGE DATA COLLECTION AND IMPLEMENTATION OF DEEP LEARNING-BASED MODEL IN DETECTING MONKEYPOX DISEASE USING MODIFIED VGG16
            產生出資料強化後的影像
        '''
        print("\nAugmentation four monkeypox image")
        data_size = self.get_processing_Augmentation(generator_data.monkeyPox_dic, 4, data_size)
        

        # 製作標準資料增強
        '''
            這裡我想要做的是依照paper上的資料強化IMAGE DATA COLLECTION AND IMPLEMENTATION OF DEEP LEARNING-BASED MODEL IN DETECTING MONKEYPOX DISEASE USING MODIFIED VGG16
            產生出資料強化後的影像
        '''
        print("\nAugmentation five monkeypox image")
        data_size = self.get_processing_Augmentation(generator_data.monkeyPox_dic, 5, data_size)

        self.stop = 2500
        # 皰疹資料
        print("\nAugmentation one herpes image")
        data_size = 0
        self.augmentation_image_labels = generator_data.herpes_label
        data_size = self.get_processing_Augmentation(generator_data.original_herpes_dict, 1, data_size)

        # 皰疹資料
        print("\nAugmentation four herpes image")
        data_size = self.get_processing_Augmentation(generator_data.original_herpes_dict, 4, data_size)

        # 皰疹資料
        print("\nAugmentation five herpes image")
        data_size = self.get_processing_Augmentation(generator_data.original_herpes_dict, 5, data_size)

        print()
        pass

    def process_main(self, labels, save_roots, stardand, data_size):
        '''
            Parameter:
                labels = 取得資料的標籤
                save_root = 要儲存資料的地方
                strardand = 要使用哪種Image Augmentation
        '''
        image_processing = Read_image_and_Process_image()

        for label in labels: # 分別對所有類別進行資料強化
            image = self.load_data(label) # 取的資料
            save_root = make_save_root(label, save_roots) # 合併路徑
            if judgeRoot_makeDir(save_root): # 判斷要存的資料夾存不存在，不存在則創立
                print("The file is exist")
            train_Generator = image_processing.data_enhancement(stardand) # 取的要做怎樣的資料強化
            stop_counter = 0
            for batches in train_Generator.flow(image, batch_size = 16): # 執行資料強化
                ''' 
                    程式碼中的 batch_size 參數被設置為 12, 這表示每次從訓練資料集中產生 12 個影像資料，作為一個 batch。當程式碼迭代 train_Generator 物件時，每次從訓練資料集中取出一個 batch 的影像，並逐一處理其中的每個影像。

                    在迭代過程中, counter 變數用於計算存儲的 Numpy 陣列檔案的數量，而 i 變數用於計算迭代的次數。當 i 的值是 417 的倍數時, if i % 417 == 0: 條件就會成立，進而執行 break 語句，退出外層迴圈。因此，最多只會從訓
                    練資料集中產生 417 個 batch 的影像資料。如果資料集中的影像總數不能被 12 整除，最後一個 batch 的影像數量會少於 12。因此, 最終產生的 Numpy 陣列檔案數量可能小於 image 資料集的影像總數除以 12。

                    總之，根據程式碼的設計，最多只會從訓練資料集中產生 417 個 batch 的影像資料，並將它們存儲為 Numpy 陣列檔案。在最後一個 batch 中的影像數量可能少於 12。

                    * train_Generator: 是一個ImageDataGenerator物件, 它從訓練資料中產生影像資料，這些影像資料可以用於訓練神經網路模型。
                    * flow(): 方法是ImageDataGenerator物件的一個方法, 它可以從資料集中產生一個batch的影像資料。image 是要傳遞給ImageDataGenerator的影像資料, batch_size 是一個batch中包含的影像數量。
                    * for batch in train_Generator.flow(image, batch_size = 12): 語句會迭代ImageDataGenerator物件產生的影像batch, 這些影像batch會逐一傳遞給batch 變數。
                    * for batches in batch: 語句會迭代batch中的每個影像資料, 這些影像資料會逐一傳遞給batches 變數。
                    * self.save_dir("image_" + label + str(counter) + ".npy", batches): 語句會以Numpy陣列的形式將每個影像資料存儲為一個Numpy陣列檔案, 檔案名稱會包含影像標籤和計數器。
                    * counter += 1: 語句會將計數器增加1, 以便標識存儲的Numpy陣列檔案。
                    * i += 1: 語句會增加迭代器的值, 以便在每417個影像batch之後退出迴圈。
                    * if i % 417 == 0: break 語句會檢查迭代器是否達到了417的倍數, 如果是, 就會退出外層的迴圈, 以便結束影像資料的存儲。
                '''
                for batch in batches: # 分別抓出每一張照片來儲存
                    save_dir("image_" + label + str(data_size) + ".png", save_root, batch) # 存檔
                    data_size += 1
                    stop_counter += 1
                if stop_counter >= self.stop: # 若做指定次數則停止
                    break
            print(str(label) + "有" + str(stop_counter) + "筆資料")

        return data_size

    def load_data(self, label):
        '''Images is readed by myself'''
        image_processing = Read_image_and_Process_image()
        img = image_processing.Data_Augmentation_Image(self.get_data_roots[label])
        return img
    
    def get_processing_Augmentation(self, original_image_root : dict, Augment_choose, data_size):
        self.get_data_roots = original_image_root # 要處理的影像路徑
        data_size = self.process_main(self.augmentation_image_labels, self.Augmentation_image_save_root, Augment_choose, data_size) # 執行
        return data_size
    
    def save_the_Generator_image(self):
        pass