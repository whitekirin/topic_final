from loadData_and_MakeImageGenerator.LoadData import Loding_Data_Root
from initialization.process_initialization import incoming_generator_data
from loadData_and_MakeImageGenerator.load_and_ImageGenerator import Load_ImageGenerator
import os
from loadData_and_MakeImageGenerator.make_ImageGenerator import Image_generator
from initialization.process_initialization import incoming_MonkeyPox_parameters

class Load_paper_Data:
    def __init__(self) -> None:
        load = Loding_Data_Root()

        # 資料擴增後的儲存路徑
        self.standard_root = "../../Dataset/paper/Training/standard_generator_dataset"
        self.myself_root = "../../Dataset/paper/Training/myself_generator_dataset"
        self.paperlabel = load.get_paper_monkeypox_labels() # paper資料的label
        self.paperdata = load.get_paper_monkeypox_data() # 將paper資料的內容包成一個list
        self.cut_size = 0

        self.process_main(load) # 執行
        pass
    def process_main(self, load : Loding_Data_Root):
        generator = Load_ImageGenerator()
        MonKeyPoxDataRoot = "../../Dataset/paper/Training/Monkeypox_Skin_Image_Dataset" # 讀猴痘、水痘資料集

        # 將paper用的資料集獨立出來(測試)
        self.paperDataRoot = "../../Dataset/paper/TestData"
        self.cut_size = 0.1
        self.Indepment_paper_image_data(load) # 處理獨立資料

        # 將paper用的資料集獨立出來(驗證)
        self.paperDataRoot = "../../Dataset/paper/ValidationData"
        self.cut_size = 0.2
        self.Indepment_paper_image_data(load) # 處理獨立資料

        if not os.path.exists(self.myself_root): # 當資料增強的資料夾不存在，則進行資料強化
            get_paper_monkeypox_image_data = generator.make_generator_data(load, MonKeyPoxDataRoot, self.paperlabel, self.paperdata) # 取回原始影像的影像路徑
            generator_data = incoming_generator_data([], self.paperlabel, get_paper_monkeypox_image_data, {}, {}) # 將資料包成一個class(類似其他語言中的struct)
            Image_generator(generator_data, 2, "MonkeyPox") # 執行資料強化
        else: # 否則則顯示提示，告訴使用者資料增強的資料已存在
            print("standard data and myself data are exist\n")
        
        self.read_monkeyPox_data = load.process_main("monkeypox") # 去執行載入資料
        # self.read_monkeyPox_data = self.get_original_data(load) # 去執行載入資料
        pass
    # not os.path.exists(self.standard_root) or 

    def Indepment_paper_image_data(self, load : Loding_Data_Root): # 分割出獨立的資料集(test, validation)
        make_generator = Load_ImageGenerator(self.paperDataRoot)
        make_generator.test_size = self.cut_size

        monkeypox_testData = load.get_content_dic(self.paperlabel, self.paperdata) # 將label與將資料包成list的資料在包成一個dict
        generator = incoming_generator_data([], self.paperlabel, self.paperDataRoot) # 將資料包成一個class(類似其他語言中的struct)
        generator.choose_generator_save_root(2)
        paper_testData = load.get_data_root(generator.original_monkeyPox_dataRoot, monkeypox_testData, self.paperlabel) # 取得原始資料集中的檔案路徑
        make_generator.process_of_Test_data({}, paper_testData, {}, self.paperlabel, 3) # 執行獨立切割

    def get_original_data(self, load : Loding_Data_Root): # 讀取MonkeyPox原始資料集
        MonkeyPox = incoming_MonkeyPox_parameters()
        # 製作傳入label
        MonKeyPoxlabels = load.get_MonkeyPox_labels()
        # 將資料合併成一個list(初始化，裡面資料是空的)
        MonkeyPox_data = load.get_MonkeyPox_data()

        get_MonkeyPox_image_data = load.get_content_dic(MonKeyPoxlabels, MonkeyPox_data) # 將label與data合併成一個dict
        generator_data = incoming_generator_data([], MonKeyPoxlabels, get_MonkeyPox_image_data, {}, {}) # 將資料合併成一個class
        generator_data.choose_generator_save_root(2)

        # 多補一個類別進MonkeyPox的list
        MonKeyPoxlabels.append("Measles")
        MonkeyPox_data.append(MonkeyPox.measles)

        get_MonkeyPox_image_data.setdefault("Measles", MonkeyPox_data[-1]) # 將個新的補進原始的dict

        get_MonkeyPox_image_data = load.get_data_root(generator_data.original_monkeyPox_dataRoot, get_MonkeyPox_image_data, MonKeyPoxlabels)
        read_monkeyPox_data = load.reconvery_monkeypox_data(get_MonkeyPox_image_data, MonkeyPox)
        read_monkeyPox_data.measles = get_MonkeyPox_image_data["Measles"] # 額外將Measles補過去

        return read_monkeyPox_data


