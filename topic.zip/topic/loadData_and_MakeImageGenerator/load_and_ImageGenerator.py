from loadData_and_MakeImageGenerator.LoadData import Loding_Data_Root
from loadData_and_MakeImageGenerator.make_ImageGenerator import Image_generator
from initialization.process_initialization import incoming_generator_data
from Read_and_process_image.ReadAndProcess import Read_image_and_Process_image
from model_data_processing.processing_for_cut_image import file_image_cut
from _validation.ValidationTheEnterData import validation_the_enter_data
from File_processing.file_processing import judge_file_exist, make_dir, make_save_root
import os
import shutil

class Load_ImageGenerator:
    '''
    這是一個拿來進行資料強化的物件，最主要結合了學姊給的資料強化與我自行設定的資料強化。
藉由此物件先將資料讀取出來，並將資料分別進行資料強化，利用資料強化來迷部資料的不平衡
這只是其中一個實驗

Parmeter
    standard_root: 做跟學姊給的資料強化同一種的資料強化
    myself_root: 資料強化的內容參數是我自己設定的
    IndependentDataRoot: 要存回去的資料夾路徑
    Herpeslabels: 皰疹的類別
    MonKeyPoxlabels: 猴痘的類別(猴痘、水痘、正常)
    herpes_data: 合併herpes Dataset的資料成一個List
    MonkeyPox_data: 合併MonkeyPox DataSet 的資料成一個List
    '''
    def __init__(self, IndependentDataRoot = "") -> None:
        self.load = Loding_Data_Root()
        self.validation = validation_the_enter_data()
        
        # 製作傳入label
        self.Herpeslabels = self.load.get_herpes_labels()
        self.MonKeyPoxlabels = self.load.get_MonkeyPox_labels()
        
        # 將資料合併成一個list(初始化，裡面資料是空的)
        self.herpes_data = self.load.get_herpes_data()
        self.MonkeyPox_data = self.load.get_MonkeyPox_data()
        self.abnormal_data = []

        self.test_size = 0.2

        # 製作網址
        self.myself_root = "../../Dataset/Topic/Training/myself_generator_dataset" # 資料增強後資料的路徑
        self.normal_Generator_root = "../../Dataset/Topic/Training/myself_normal_data_generator_dataset" # 資料增強後資料的路徑
        self.original_MonKeyPoxDataRoot = "../../Dataset/Topic/Training/Monkeypox_Skin_Image_Dataset" # 讀猴痘、水痘資料集
        self.original_herpes_root = "../../Dataset/Topic/Training/ImageDataset_filtered" # 讀原始資料集的資料
        self.original_abnormal_dataRoot = "../../Dataset/Topic/Training/Abnormal" # 隨便找一個資料集來當異常
        self.IndependentDataRoot = IndependentDataRoot # 獨立資料的網址

        pass
        
    def get_RootData(self):
        return self.herpes_data, self.MonkeyPox_data, self.abnormal_data

    def process_main(self):        
        # 將資料合併成一個list(初始化，裡面資料是空的)
        herpes_data, MonkeyPox_data, abnormal_data = self.get_RootData()
        
        # 將測試資料獨立出來
        self.IndependentDataRoot = "../../Dataset/Topic/TestData"
        self.process_IndependentData_main()

        # 將驗證資料獨立出來
        self.IndependentDataRoot = "../../Dataset/Topic/ValidationData"
        self.test_size = 0.1
        self.process_IndependentData_main()

        if not judge_file_exist(self.myself_root): # 判斷是否進行了資料強化
            # 製作讀檔字典並回傳檔案路徑
            get_original_Herpes_image_data = self.make_generator_data(self.original_herpes_root, self.Herpeslabels, herpes_data)
            get_MonkeyPox_image_data = self.make_generator_data(self.original_MonKeyPoxDataRoot, self.MonKeyPoxlabels, MonkeyPox_data)
            get_abnormal_image_data = self.make_generator_data(self.original_abnormal_dataRoot, "abnormal", abnormal_data, 2)

            # 儲存資料強化後資料
            generator_data = incoming_generator_data(self.Herpeslabels, self.MonKeyPoxlabels, get_MonkeyPox_image_data, get_original_Herpes_image_data, get_abnormal_image_data)
            Image_generator(generator_data) # 執行資料強化
        else:
            print("standard data and myself data are exist\n")
        
        # 執行讀檔
        return self.load.process_main()

        # 用原始資料進行實驗
        # self.abnormal = []
        # self.read_herpes_data, self.read_monkeyPox_data, self.read_abnormal_data = load.load_original_image()
        # for i in range(200):
        #     self.abnormal.append(self.read_abnormal_data[i])

    def make_generator_data(self, root, dir_label, fit_data, judge = 1):
        if judge == 1:
            get_image_dic_data = self.load.get_content_dic(dir_label, fit_data) # 製作讀檔字典
            get_image_data = self.load.get_data_root(root, get_image_dic_data, dir_label) # 取回路徑資料
        if judge == 2:
            get_image_dic_data = {dir_label : fit_data}
            get_image_data = self.load.get_data_root(root, get_image_dic_data, [dir_label], 2) # 取回路徑資料

        return get_image_data

    def process_IndependentData_main(self):
        herpes_data, MonkeyPox_data, abnormal_data = self.get_RootData()

        get_Herpes_image_data = self.make_generator_data(self.original_herpes_root, self.Herpeslabels, herpes_data)
        get_MonkeyPox_image_data = self.make_generator_data(self.original_MonKeyPoxDataRoot, self.MonKeyPoxlabels, MonkeyPox_data)
        get_abnormal_image_data = self.make_generator_data(self.original_abnormal_dataRoot, "abnormal", abnormal_data, 2)
        
        # 合併檔案路徑，並執行獨立測試與驗證資料的切割
        total_label = self.Herpeslabels + self.MonKeyPoxlabels
        total_label.append("abnormal")

        self.process_of_Test_data(get_Herpes_image_data, get_MonkeyPox_image_data, get_abnormal_image_data, total_label)

    def process_of_Test_data(self, cut_herpes_testData_roots = {}, cut_monkeypox_testData_roots = {}, cut_abnormal_testData_root = {}, cut_TotalTestData_roots_labels = [], status = "all"):
        fileCut = file_image_cut()
        image_processing = Read_image_and_Process_image()
        i = 0

        if not os.path.exists(self.IndependentDataRoot): #若檔案不存在
            for cut_TotalTestData_roots_label in cut_TotalTestData_roots_labels: # 將資料的label一個一個讀出來
                root = make_save_root(cut_TotalTestData_roots_label, self.IndependentDataRoot) # 合併成一個路徑
                make_dir(root) # 建檔

                if self.validation.validation_string(status, "all"):
                    if i == 6: # 最後一個是異常資料
                        cut_test_data = cut_abnormal_testData_root[cut_TotalTestData_roots_label]
                    elif i >= 3 and i <= 5: # 前三個是讀水痘的資料路徑
                        cut_test_data = cut_monkeypox_testData_roots[cut_TotalTestData_roots_label]
                    else: # 後面則是讀猴痘、皰疹的資料路徑
                        cut_test_data = cut_herpes_testData_roots[cut_TotalTestData_roots_label]
                else:
                    cut_test_data = cut_monkeypox_testData_roots[cut_TotalTestData_roots_label]
                    
                label = image_processing.make_label_list(len(cut_test_data), 0) # 製作假的label
                cut_data = fileCut.cut_data(cut_test_data, label, self.test_size) # 切割出特定數量的資料
                
                for data in cut_data[1]:
                    shutil.move(data, root) # 移動資料進新的資料夾
                i += 1