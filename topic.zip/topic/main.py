from experiments.experiment import experiments
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed, wait, ALL_COMPLETED
from File_processing.file_processing import save_dir, judgeRoot_makeDir, make_save_root
from loadData_and_MakeImageGenerator.load_and_ImageGenerator import Load_ImageGenerator
from image_enhancemen.image_enhancement import adaptive_histogram_equalization, Remove_Background, shapen
from Read_and_process_image.ReadAndProcess import Read_image_and_Process_image
from model_data_processing.processing import shuffle_data
import tensorflow as tf
import os
import time

if __name__ == "__main__":
    with ProcessPoolExecutor() as executor: ## 默认为1
        print('TensorFlow version:', tf.__version__)
        physical_devices = tf.config.experimental.list_physical_devices('GPU')
        print(physical_devices)
        assert len(physical_devices) > 0, "Not enough GPU hardware devices available"
        tf.config.experimental.set_memory_growth(physical_devices[0], True)
        os.environ["CUDA_VISIBLE_DEVICES"]='0'
 
        loading_data = Load_ImageGenerator()
        read_herpes_data, read_monkeyPox_data, read_abnormal_data = loading_data.process_main()

        print("原始猴痘數量: ", len(read_monkeyPox_data.monkey_pox))
        print("原始水痘數量: ", len(read_monkeyPox_data.Chickenpox))
        print("原始BP數量: ", len(read_herpes_data.bp))
        print("原始PF數量: ", len(read_herpes_data.pf))
        print("原始PV數量: ", len(read_herpes_data.pv))
        print("原始正常數量: ", len(read_monkeyPox_data.normal))
        print("原始異常數量: ", len(read_abnormal_data))

        total = len(read_monkeyPox_data.monkey_pox) + len(read_monkeyPox_data.Chickenpox) + len(read_herpes_data.bp) + len(read_herpes_data.pf)+ len(read_herpes_data.pv) + len(read_monkeyPox_data.normal) + len(read_abnormal_data)
        print("總共有: ", total, " 個")

        experiment = experiments()
        image_processing = Read_image_and_Process_image()


        total_monkeypox_data = experiment.get_data_dic(read_monkeyPox_data.Chickenpox, read_monkeyPox_data.monkey_pox, read_monkeyPox_data.normal) # 將MonkeyPox的資料做成dict的形式
        total_herpes_data = experiment.get_data_dic(read_herpes_data.bp, read_herpes_data.pf, read_herpes_data.pv) # 將Herpes的資料做成dict的形式
        total_abnormal_data = {"classify1" : read_abnormal_data, "classify_label1" : []}

        herpes_class_num, monkeypox_class_num, abnormal_class_num = image_processing.get_one_hot_label() # 取得7分類資料經過one-hot Encoding後的label
        
        herpes_train, herpes_train_label = experiment.calculateLabel_and_getTrainData(total_herpes_data, herpes_class_num) # 將前面包成dict的資料攤平成一個list，內容包含imgData與imgLabel
        MonkeyPox_train, MonkeyPox_train_label = experiment.calculateLabel_and_getTrainData(total_monkeypox_data, monkeypox_class_num)
        abnormal_train, abnormal_train_label = experiment.calculateLabel_and_getTrainData(total_abnormal_data, abnormal_class_num, "abnormal")
        training_data = experiment.merge_all_image_data(herpes_train, MonkeyPox_train, abnormal_train) # 將訓練資料合併成一個list
        training_label = experiment.merge_all_image_data(herpes_train_label, MonkeyPox_train_label, abnormal_train_label) #將訓練資料的label合併成一個label的list

        # training_data, train_label = shuffle_data(training_data, training_label)
        # training_data = list(training_data)

        normal = []
        chickenpox = []
        monkeypox = []
        i = 0
        while True:
            if i != len(training_data):
                split = training_data[i].split("\\")
                if split[-2] == "Normal":
                    normal.append(training_data[i])

                    del training_data[i]
                    del training_label[i]
                    i -= 1
                if split[-2] == "Chickenpox":
                    chickenpox.append(training_data[i])

                    del training_data[i]
                    del training_label[i]
                    i -= 1
                if split[-2] == "Monkeypox":
                    monkeypox.append(training_data[i])

                    del training_data[i]
                    del training_label[i]
                    i -= 1
            else:
                break
            i += 1

        start = time.time()

        # 針對其他資料執行值方圖等化加去背
        trains_another = list(executor.map(image_processing.get_data, training_data)) # 多執行續讀檔
        trains = list(executor.map(adaptive_histogram_equalization, trains_another))

        # 針對正常資料做值方圖等化加去背
        train_normal = list(executor.map(image_processing.get_data, normal)) # 多執行續讀檔
        normal = list(executor.map(Remove_Background, train_normal)) # 多執行續去背
        normal_data = list(executor.map(adaptive_histogram_equalization, normal))

        # 針對猴痘水痘進行讀檔
        Chickenpox = list(executor.map(image_processing.get_data, chickenpox)) # 多執行續讀檔
        train_chickenpox = list(executor.map(shapen, Chickenpox))

        Monkeypox = list(executor.map(image_processing.get_data, monkeypox)) # 多執行續讀檔
        train_monkeypox = list(executor.map(shapen, Monkeypox)) # 銳化
        

        # counter = 0
        # save_root = "../../Dataset/Topic/normal_image_change"
        # judgeRoot_makeDir(save_root)
        # for d in normal_data:
        #     save_dir(str(counter) + ".png", save_root, d)
        #     counter += 1
        
        # normal_path = []
        # for i in range(counter):
        #     normal_path.append(make_save_root(str(i) + ".png", save_root))
        # normal_data = list(executor.map(image_processing.get_data, normal_path)) # 多執行續讀檔

        for All_Normal_Data in normal_data:
            trains.append(All_Normal_Data)
            training_label.append([0, 0, 0, 0, 0, 1, 0])

        for All_Chhickenpox_Data in train_chickenpox:
            trains.append(All_Chhickenpox_Data)
            training_label.append([0, 0, 0, 1, 0, 0, 0])

        for All_Monkeypox_Data in train_monkeypox:
            trains.append(All_Monkeypox_Data)
            training_label.append([0, 0, 0, 0, 1, 0, 0])

        
        total_trains, train_label = shuffle_data(trains, training_label)
        training_data = list(total_trains)

        print(len(training_data))
        training_data, train_label = image_processing.image_data_processing(training_data, train_label) # 將讀出來的檔做正規化。降label轉乘numpy array 格式

        end = time.time()
        print("\n\n\n讀取訓練資料(70000)執行時間：%f 秒\n\n" % (end - start))
        experiment.processing_main(1, training_data, train_label)