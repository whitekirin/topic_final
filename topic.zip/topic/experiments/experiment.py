from model_construction.pre_train_model_construction import VGG19_model, DenseNet201_model, Resnet50_model, Original_DenseNet201_model, Change_Dropout_Coefficient
from model_construction.pre_train_model_construction import Add_residual_block_and_two_layers_in_Xception_model, Add_residual_block_and_five_layers_in_Xception_model, Add_attention_block_in_Xception_model, Change_Regularization_Coefficient, Add_Activation_in_Xception
from initialization.process_initialization import incoming_Herpes_parameters, incoming_MonkeyPox_parameters
from model_data_processing.processing import shuffle_data, sparate_fixed_data
from all_models_tools.all_model_tools import call_back, add_optimizers_function
from Read_and_process_image.ReadAndProcess import Read_image_and_Process_image
from draw_tools.draw import plot_history, draw_heatmap
from model_data_processing.processing_for_cut_image import file_image_cut
from _validation.ValidationTheEnterData import validation_the_enter_data
from model_construction.pre_train_model_construction import add_regularizers_L1, add_regularizers_L2, add_regularizers_L1L2, add_bias_regularizers, original_VGG19, Add_residual_block_and_three_layers_in_Xception_model
from model_construction.pre_train_model_construction import VGG19_many_Dense_layer, ResNet50_many_Dense_layer, Xception_many_Dense_layer, DenseNet201_many_Dense_layer, Original_Xception_model
from File_processing.file_processing import judge_file_exist, make_dir, make_save_root, judgeRoot_makeDir, save_CSV_file
from merge_class.merge import merge
from Grad_CAM.Grad_cam import Grad_CAM
from initialization.process_initialization import init_variable
from sklearn.metrics import confusion_matrix
from keras.models import Model
import pandas as pd
import keras
import datetime
import numpy as np
import time
import os

class experiments(init_variable):
    def __init__(self):
        '''
            傳入參數:
                * experiment_times: 執行次數
                * Herpes: Herpes物件, 裡面包含(bp, pf, pv)
                * monkeypox: monkeypox物件, 裡面包含(Chickenpox, MonkeyPox, Normal, Measles)
                * abnormal: 分類為異常的影像資料
                * status: 決定我要用的資料集是paper還是我自己的7分類資料集, 若為all則為7分類,若為其他則是執行paper的資料集
            
            parmeter:
                * model_name: 取名，告訴我我是用哪個模型(可能是預處理模型/自己設計的模型)
                * generator_batch_size: 每一批次要讀多少檔出來
                * epoch: 訓練次數
                * train_batch_size: 訓練時要多少批次的影像為1組
                * generator_batch_size: 減少圖片數量對GPU記憶體的用量, 減少張數用的
                * 
        '''
        super().__init__() # 初始化父物件

        self.validation_obj = validation_the_enter_data() # 呼叫驗證物件
        self.cut_image = file_image_cut() # 呼叫切割影像物件
        self.image_processing = Read_image_and_Process_image()
        self.merge = merge()

        self.model_name = "Xception" # 取名，告訴我我是用哪個模型(可能是預處理模型/自己設計的模型)
        self.experiment_name = "Remove background and real image with normal image"
        self.file_name = "Remove background of Chickenpox with normal image"
        self.generator_batch_size = 100
        self.epoch = 2000
        self.train_batch_size = 32
        self.counter = 0
        self.layers = 4

        self.convolution_name = self.get_layer_name(self.model_name)
        self.grad = Grad_CAM(self.counter, self.layers, self.model_name, self.experiment_name, self.convolution_name)
        pass

    def processing_main(self, experiment_times, train, train_label):
        start = time.time()
        self.cut_image.process_main() # 呼叫處理test Data與Validation Data的function
        end = time.time()
        print("讀取testing與validation資料(154)執行時間：%f 秒\n" % (end - start))

        # 將處理好的test Data 與 Validation Data 丟給這個物件的變數
        self.test, self.test_label = self.cut_image.test, self.cut_image.test_label
        self.validation, self.validation_label = self.cut_image.validation, self.cut_image.validation_label

        for i in range(experiment_times):
            cnn_model = self.construct_model() # 呼叫讀取模型的function
            
            model_dir = '../../save_the_best_model/Topic/' + self.experiment_name + '/best_model( 2023-10-30 )-2.h5' # 這是一個儲存模型權重的路徑，每一個模型都有一個自己權重儲存的檔
            if os.path.exists(model_dir): # 如果這個檔案存在
                cnn_model.load_weights(model_dir) # 將模型權重讀出來
                print("讀出權重\n")

            Optimizer = add_optimizers_function(0.045, 3) # 決定優化器與學習率

            cnn_model.compile(
                loss='categorical_crossentropy', 
                optimizer = Optimizer, 
                metrics=
                    [
                        'accuracy', 
                        keras.metrics.Precision(name='precision'), 
                        keras.metrics.Recall(name='recall'),
                        keras.metrics.AUC(name = 'AUC'),
                    ]
                )  
                     
            train_data = self.image_processing.data_enhancement(3) # 叫入ImageGeneratorr的物件，為了要讓我訓練時可以分批次讀取資料，GPU記憶體才不會爆
            cnn_model.summary() # 顯示模型架構
            print("\n\n\n讀取訓練資料(70000)執行時間：%f 秒\n\n" % (end - start))
            history = cnn_model.fit(
                train_data.flow(train, train_label, batch_size = self.generator_batch_size),
                epochs = self.epoch, 
                batch_size = self.train_batch_size,
                validation_data = (self.validation, self.validation_label),
                callbacks = call_back(self.experiment_name, self.counter) # 呼叫 call back list
                # callbacks = call_back("best_model", self.counter) # 呼叫 call back list
            )

            self.record_matrix_image(cnn_model, self.experiment_name, self.counter) # 紀錄混淆矩陣的function
            loss, accuracy, precision, recall, AUC = cnn_model.evaluate(self.test, self.test_label) # 預測結果

            # 防分母為0的時候
            if recall == 0 or precision == 0:
                f = 0
            else:
                f = (1 + 0.5 * 0.5) * ((recall * precision) / (0.5 * 0.5 * recall + precision))
                
            self.save_evertime_result(loss, accuracy, precision, recall, AUC, f)
            self.recoder(loss, accuracy, precision, recall, AUC, f) # 紀錄當前訓練完之後的預測結果
            self.record_everyTime_test_result(loss, accuracy, precision, recall, AUC, f, self.counter, self.experiment_name) # 紀錄當前訓練完之後的預測結果，並輸出成csv檔
            
            plot_history(history, "train" + str(self.counter), self.experiment_name) # 將訓練結果化成圖，並將化出來的圖丟出去儲存
            self.grad.process_main(self.test, cnn_model, self.test_label, self.counter)
            self.counter += 1
        print(self.calculate_average_target(experiment_times, self.model_name)) # 輸出最終平均結果

    def calculateLabel_and_getTrainData(self, total_image_data, image_oneHot_label, label_name = "another"):
        if not self.validation_obj.validation_string(label_name, "abnormal"):
            total_data = self.image_processing.calculate_label(total_image_data, image_oneHot_label) # 去計算取得回來的label每一項有幾個，並包成dict回傳
            return self.cut_image.get_train_data(total_data) # 將前面包成dict的資料攤平成一個list，內容包含imgData與imgLabel
        else:
            total_abnormal_data = self.image_processing.calculate_label(total_image_data, image_oneHot_label, 2)
            return total_abnormal_data["classify1"], total_abnormal_data["classify_label1"]

    def merge_all_image_data(self, herpes, monkeypox, abnormal):
        merged_data = [herpes, monkeypox, abnormal]

        return self.merge.merge_data_main(merged_data, 0, 3)

    def construct_model(self):
        '''決定我這次訓練要用哪個model'''

        # 使用四種模型進行原始資料與Data Augmentation的訓練
        # model_input, output = VGG19_model()
        # model_input, output = Resnet50_model()
        # model_input, output = DenseNet201_model()
        # model_input, output = Xception_model()

        # 決定模型的輸出層架構
        # model_input, output = VGG19_many_Dense_layer(start_unit = 128,layers = 2)
        # model_input, output = VGG19_many_Dense_layer(start_unit = 512,layers = 4)
        # model_input, output = VGG19_many_Dense_layer(start_unit = 1024,layers = 5)

        # model_input, output = ResNet50_many_Dense_layer(start_unit = 128,layers = 2)
        # model_input, output = ResNet50_many_Dense_layer(start_unit = 256,layers = 3)
        # model_input, output = ResNet50_many_Dense_layer(start_unit = 512,layers = 4)
        # model_input, output = ResNet50_many_Dense_layer(start_unit = 1024,layers = 5)

        # model_input, output = Original_Xception_model()
        # model_input, output = Original_DenseNet201_model()
        # model_input, output = original_VGG19()

        # model_input, output = Xception_many_Dense_layer(start_unit = 64,layers = 2)
        # model_input, output = Xception_many_Dense_layer(start_unit = 256,layers = 3)
        # model_input, output = Xception_many_Dense_layer(start_unit = 512,layers = 4)
        # model_input, output = Xception_many_Dense_layer(start_unit = 1024,layers = 5)

        # model_input, output = DenseNet201_many_Dense_layer(start_unit = 128,layers = 2)
        # model_input, output = DenseNet201_many_Dense_layer(start_unit = 256,layers = 3)

        # model_input, output =  add_regularizers_L1()
        # model_input, output = add_regularizers_L2()
        # model_input, output =  add_regularizers_L1L2()

        # model_input, output = add_bias_regularizers()

        # model_input, output = add_layers1_L2(self.layers)
        # model_input, output = add_layers_another_L2(self.layers, 64)

        # 添加殘差網路
        # model_input, output = Add_residual_block_and_two_layers_in_Xception_model()
        # model_input, output = Add_residual_block_and_three_layers_in_Xception_model()
        # model_input, output = Add_residual_block_and_five_layers_in_Xception_model()

        # 添加注意力機制
        # model_input, output = Add_attention_block_in_Xception_model()

        # model_input, output = Add_Activation_in_Xception()

        # 加上 L1、L2、L1L2正則化
        # model_input, output = add_regularizers_L1()

        # 比較不同位置的正則化
        # model_input, output = add_bias_regularizers()

        # 比較不同L2正則化係數
        # model_input, output = Change_Regularization_Coefficient(0.00001)

        # 比較不同Dropout係數
        # coffeicient = 0.53
        # while coffeicient <= 0 or coffeicient >= 0.6:
        #     coffeicient = random.random()
        #     coffeicient = round(coffeicient, 2)
        # print(coffeicient)
        model_input, output = Change_Dropout_Coefficient(0.6)

        cnn_model = Model(inputs = model_input, outputs = output)

        return cnn_model

    def record_matrix_image(self, cnn_model : Model, model_name, index):
        '''劃出混淆矩陣(熱力圖)'''
        result = cnn_model.predict(self.test) # 利用predict function來預測結果
        result = np.argmax(result, axis = 1)  # 將預測出來的結果從one-hot encoding轉成label-encoding
        y_test = np.argmax(self.test_label, axis = 1)    
        matrix = confusion_matrix(result, y_test, labels=[0, 1, 2, 3, 4, 5, 6]) # 丟入confusion matrix的function中，以形成混淆矩陣
        draw_heatmap(matrix, model_name, index) # 呼叫畫出confusion matrix的function

    def record_everyTime_test_result(self, loss, accuracy, precision, recall, auc, f, indexs, model_name):
        '''記錄我單次的訓練結果並將它輸出到檔案中'''
        Dataframe = pd.DataFrame(
                {
                    "model_name" : str(model_name),
                    "loss" : "{:.2f}".format(loss), 
                    "precision" : "{:.2f}%".format(precision * 100), 
                    "recall" : "{:.2f}%".format(recall * 100),
                    "accuracy" : "{:.2f}%".format(accuracy * 100), 
                    "f" : "{:.2f}%".format(f * 100), 
                    "AUC" : "{:.2f}%".format(auc * 100)
                }, index = [indexs])
        save_CSV_file("train_result", Dataframe)

    def recoder(self, loss, accuracy, precision, recall, auc, f):
        self.ave_loss += loss
        self.ave_accuracy += accuracy
        self.ave_precision += precision
        self.ave_recall += recall
        self.ave_auc += auc
        self.ave_f += f
        pass

    def save_evertime_result(self, loss, accuracy, precision, recall, auc, f):
        self.std_losses.append(loss)
        self.std_precision.append(precision)
        self.std_recall.append(recall)
        self.std_accuracy.append(accuracy)
        self.std_fScore.append(f)
        self.std_AUC.append(auc)
    
    def calculate_std(self):
        standard_deviation_loss = np.std(self.std_losses)
        standard_deviation_precision = np.std(self.std_precision)
        standard_deviation_recall = np.std(self.std_recall)
        standard_deviation_accuracy = np.std(self.std_accuracy)
        standard_deviation_f = np.std(self.std_fScore)
        standard_deviation_AUC = np.std(self.std_AUC)

        return standard_deviation_loss, standard_deviation_precision, standard_deviation_recall, standard_deviation_accuracy, standard_deviation_f, standard_deviation_AUC

    def calculate_average_target(self, experiment_times, model_name):
            '''計算平均訓練結果，並將資料輸出到檔案中'''
            self.ave_loss /= experiment_times
            self.ave_precision /= experiment_times
            self.ave_recall /= experiment_times
            self.ave_accuracy /= experiment_times
            self.ave_f /= experiment_times
            self.ave_auc /= experiment_times

            standard_deviation = self.calculate_std()

            Dataframe = pd.DataFrame(
                {
                    "model_name" : str(model_name),
                    "loss" : "{:.2f}±{:.3f}".format(self.ave_loss, standard_deviation[0]), 
                    "precision" : "{:.2f}%±{:.3f}".format(self.ave_precision * 100, standard_deviation[1]), 
                    "recall" : "{:.2f}%±{:.3f}".format(self.ave_recall * 100, standard_deviation[2]),
                    "accuracy" : "{:.2f}%±{:.3f}".format(self.ave_accuracy * 100, standard_deviation[3]), 
                    "f" : "{:.2f}%±{:.3f}".format(self.ave_f * 100, standard_deviation[4]), 
                    "AUC" : "{:.2f}%±{:.3f}".format(self.ave_auc * 100, standard_deviation[5])
                }, index = [0])
            save_CSV_file("average_result", Dataframe)
            return Dataframe

    def get_layer_name(self, model_name):
        if(self.validation_obj.validation_string(model_name, "VGG19")):
            return "block5_conv4"
        if(self.validation_obj.validation_string(model_name, "ResNet50")):
            return "conv5_block3_3_conv"
        if(self.validation_obj.validation_string(model_name, "Xception")):
            return "block12_sepconv2"
        if(self.validation_obj.validation_string(model_name, "DenseNet201")):
            return "conv5_block32_2_conv"
