class init_cut_image:
    def __init__(self):
        '''
        img_cut 物件內容初始化
        classify1 : 第一分類
        classify2 : 第二分類
        classify3 : 第三分類
        '''

        self.label_length = []

        self.test = []
        self.test_label = []

        self.validation = []
        self.validation_label = []
        
        self.train = []
        self.train_label = []

        pass
    def get_classify_img(self, judge, process_image):
        if judge == 1:
            return [process_image.bp, process_image.pf, process_image.pv]
        if judge == 2:
            return [process_image.Chickenpox, process_image.monkey_pox, process_image.normal]
        if judge == 3:
            return [process_image.Chickenpox, process_image.measles,process_image.monkey_pox, process_image.normal]
    
    def get_category_data(self, judge = 1):
        if judge == 1:
            return [[], [], [], [], [], [], [], [], [], [], [], [], [], []]
        elif judge == 2:
            return [[], [], [], [], [], [], [], []]