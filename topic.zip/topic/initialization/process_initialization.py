import numpy as np

class incoming_Herpes_parameters:
    '''初始化皰疹類別'''
    def __init__(self):
        self.bp = []
        self.pv = []
        self.pf = []
        pass

class incoming_MonkeyPox_parameters:
    '''初始化猴痘水痘類別'''
    def __init__(self):
        self.monkey_pox = []
        self.normal = []
        self.Chickenpox = []
        self.measles = []
        pass

class incoming_generator_data:
    '''初始化資料強化傳入參數'''
    def __init__(self, herpes_label = [], monkeyPox_label = [], monkeyPox_dic = {}, original_herpes_dict = {}, abnormal = {}) -> None:
        self.herpes_label = herpes_label
        self.monkeyPox_label = monkeyPox_label
        self.abnormal_label = ["abnormal"]

        self.monkeyPox_dic = monkeyPox_dic
        self.original_herpes_dict = original_herpes_dict
        self.abnormal = abnormal

        self.myself_root = "../../Dataset/Topic/Training/myself_generator_dataset"
        self.original_balance_herpes_dataRoot = "../../Dataset/Topic/Training/TzuChi_Preparation"

        self.orignal_herpes_dataRoot = "../../Dataset/Topic/Training/ImageDataset_filtered"
        self.original_monkeyPox_dataRoot = "../../Dataset/Topic/Training/Monkeypox_Skin_Image_Dataset"
        self.original_abnormal_dataRoot = "../../Dataset/Topic/Training/Abnormal"
        pass
    def choose_generator_save_root(self, judge = 1):
        if judge == 1:
            self.myself_root = "../../Dataset/Topic/Training/myself_generator_dataset"
            self.original_monkeyPox_dataRoot = "../../Dataset/Topic/Training/Monkeypox_Skin_Image_Dataset"
        if judge == 2:
            self.myself_root = "../../Dataset/paper/Training/myself_generator_dataset"
            self.original_monkeyPox_dataRoot = "../../Dataset/paper/Training/Monkeypox_Skin_Image_Dataset"

class init_variable:
    def __init__(self):
        self.ave_precision = 0.0
        self.ave_recall = 0.0
        self.ave_accuracy = 0.0
        self.ave_loss = 0.0
        self.ave_auc = 0.0
        self.ave_f = 0.0
        self.std_losses, self.std_precision, self.std_recall, self.std_accuracy, self.std_fScore, self.std_AUC = [], [], [], [], [], []

        self.train = []
        self.train_label = []

        self.test = []
        self.test_label = []
        
        self.validation = []
        self.validation_label = []

    def get_data_dic(self, classify1, classify2, classify3):
        return {
            "classify1" : classify1,
            "classify2" : classify2,
            "classify3" : classify3,

            "classify_label1" : [],
            "classify_label2" : [],
            "classify_label3" : []
        }
    
    # def classify_test_group(self, cut_image):
    #     data = cut_image.test
    #     label = np.array(cut_image.test_label)
    #     return data, label